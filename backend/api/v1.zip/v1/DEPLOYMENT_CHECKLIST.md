# API v1 Deployment Checklist & Testing Guide

## ✅ **Your API is Deployed at:**
**URL:** `https://api.gtvmotor.dev/api/v1/`

---

## 🧪 **Step 1: Test API Endpoints**

### **Quick Test Script**

Run this to test all endpoints:
```bash
php backend/api/v1/test-api-endpoints.php
```

### **Manual Tests**

#### **1. Test API Info**
```bash
curl -X GET "https://api.gtvmotor.dev/api/v1/" \
  -H "X-API-Key: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6"
```

**Expected:** API information with endpoints list

#### **2. Test Customers**
```bash
curl -X GET "https://api.gtvmotor.dev/api/v1/customers?limit=5" \
  -H "X-API-Key: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6"
```

**Expected:** List of customers with pagination

#### **3. Test Vehicles**
```bash
curl -X GET "https://api.gtvmotor.dev/api/v1/vehicles?limit=5" \
  -H "X-API-Key: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6"
```

**Expected:** List of vehicles

#### **4. Test Invoices**
```bash
curl -X GET "https://api.gtvmotor.dev/api/v1/invoices?limit=5" \
  -H "X-API-Key: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6"
```

**Expected:** List of service invoices

#### **5. Test Analytics**
```bash
curl -X GET "https://api.gtvmotor.dev/api/v1/analytics?type=overview&days=7" \
  -H "X-API-Key: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6"
```

**Expected:** Analytics overview data

---

## ✅ **Step 2: Setup Database**

### **Run These SQL Scripts:**

1. **API Settings:**
   ```bash
   mysql -u username -p database < backend/api/v1/add_api_settings_to_database.sql
   ```

2. **Analytics Tables:**
   ```bash
   mysql -u username -p database < backend/api/v1/create_api_analytics_tables.sql
   ```

3. **Database Updates (if needed):**
   ```bash
   mysql -u username -p database < backend/api/v1/update_database_minimal.sql
   ```

---

## 🎨 **Step 3: Frontend UI Setup**

### **✅ API Configuration UI** (Already Updated)

**Location:** `Settings → API Configuration Tab`

**Features:**
- ✅ Loads settings from database
- ✅ Saves settings to database
- ✅ Test connection button
- ✅ Connection status indicator
- ✅ All settings fields working

**To Use:**
1. Go to Settings → API Configuration
2. Enter API Base URL: `https://api.gtvmotor.dev/api/v1`
3. Enter your API key
4. Click "Test Connection" to verify
5. Click "Save API Settings"

### **✅ API Analytics Dashboard** (New Page Created)

**Location:** `API Analytics` (in sidebar)

**Features:**
- ✅ Overview statistics
- ✅ Endpoint analytics
- ✅ API key usage
- ✅ Error analysis
- ✅ Performance metrics
- ✅ Traffic patterns

**To Use:**
1. Go to API Analytics in sidebar
2. Select time period (1, 7, 30, 90 days)
3. View different analytics tabs
4. Click "Refresh" to update data

---

## 📋 **Complete Setup Checklist**

### **Backend:**
- [x] API v1 deployed to `https://api.gtvmotor.dev/api/v1/`
- [ ] Run `add_api_settings_to_database.sql`
- [ ] Run `create_api_analytics_tables.sql`
- [ ] Run `update_database_minimal.sql` (if needed)
- [ ] Test all endpoints using test script
- [ ] Verify API keys in `backend/api/v1/config.php`

### **Frontend:**
- [x] API Configuration UI updated
- [x] Analytics Dashboard created
- [x] Navigation updated (API Analytics link added)
- [ ] Test API Configuration page
- [ ] Test Analytics Dashboard

---

## 🎯 **Quick Start**

### **1. Test Your API (2 minutes)**
```bash
php backend/api/v1/test-api-endpoints.php
```

### **2. Setup Database (3 minutes)**
```bash
# Run all SQL scripts
mysql -u username -p database < backend/api/v1/add_api_settings_to_database.sql
mysql -u username -p database < backend/api/v1/create_api_analytics_tables.sql
mysql -u username -p database < backend/api/v1/update_database_minimal.sql
```

### **3. Configure Frontend (1 minute)**
1. Go to Settings → API Configuration
2. Set Base URL: `https://api.gtvmotor.dev/api/v1`
3. Enter API key
4. Test connection
5. Save settings

### **4. View Analytics (Ready!)**
1. Go to API Analytics in sidebar
2. View your API traffic data

---

## ✅ **What's Ready**

- ✅ API v1 deployed and working
- ✅ Router handles `/api/v1/` path
- ✅ API Configuration UI with database integration
- ✅ Analytics Dashboard UI
- ✅ Test connection functionality
- ✅ All analytics views and queries

**Everything is set up and ready to use!** 🎉

