# API v1 Write Methods Added ✅

## Summary

I've added **POST, PUT, PATCH, and DELETE** methods to your API v1 endpoints. Your API is now **full CRUD** (Create, Read, Update, Delete) instead of read-only.

---

## ✅ What Was Added

### 1. **Customers API** (`/v1/customers`)

**New Methods:**
- ✅ **POST** - Create new customer
- ✅ **PUT/PATCH** - Update existing customer
- ✅ **DELETE** - Delete customer (with safety checks)

**Features:**
- ✅ Write permission check (requires 'write' permission in API key)
- ✅ Data validation and sanitization
- ✅ Timestamp suffix removal (for frontend compatibility)
- ✅ Safety check: Cannot delete customer with vehicles/services

**Example Usage:**
```bash
# Create customer
POST /v1/customers
{
  "name": "John Doe",
  "phone": "012345678",
  "email": "john@example.com",
  "address": "Phnom Penh"
}

# Update customer
PUT /v1/customers/1
{
  "name": "John Smith",
  "phone": "098765432"
}

# Delete customer
DELETE /v1/customers/1
```

---

### 2. **Vehicles API** (`/v1/vehicles`)

**New Methods:**
- ✅ **POST** - Create new vehicle
- ✅ **PUT/PATCH** - Update existing vehicle
- ✅ **DELETE** - Delete vehicle (with safety checks)

**Features:**
- ✅ Write permission check
- ✅ Customer validation (must exist)
- ✅ Vehicle model lookup by name
- ✅ Safety check: Cannot delete vehicle with services

**Example Usage:**
```bash
# Create vehicle
POST /v1/vehicles
{
  "customer_id": 1,
  "plate_number": "ABC-1234",
  "model": "SOBEN",
  "year": 2023,
  "vin_number": "VIN123456"
}

# Update vehicle
PUT /v1/vehicles/1
{
  "current_km": 50000,
  "warranty_end_date": "2026-01-01"
}

# Delete vehicle
DELETE /v1/vehicles/1
```

---

### 3. **Invoices API** (`/v1/invoices`)

**Status:** ⚠️ **Read-only for now** (invoices are complex - involve services + service_items)

**Recommendation:**
- Invoices (services) should be created/updated through a dedicated service management system
- For now, invoices remain **read-only** for safety
- You can add write methods later if needed

---

## 🔐 Security Features

### Permission Checks
All write operations require **'write' permission** in API key:

```php
// Example API key config
'your_api_key' => [
    'permissions' => ['read', 'write'], // ← Must have 'write'
    'rate_limit' => 1000,
    'active' => true
]
```

**Read-only keys** will get:
```json
{
  "success": false,
  "error": "API key does not have write permission."
}
```

---

## 📋 API Methods Summary

| Endpoint | GET | POST | PUT/PATCH | DELETE |
|----------|-----|------|-----------|--------|
| `/v1/customers` | ✅ | ✅ | ✅ | ✅ |
| `/v1/vehicles` | ✅ | ✅ | ✅ | ✅ |
| `/v1/invoices` | ✅ | ❌ | ❌ | ❌ |

---

## 🧪 Testing Examples

### Create Customer
```bash
curl -X POST "https://api.gtvmotor.dev/v1/customers" \
  -H "X-API-Key: your_key" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test Customer",
    "phone": "012345678",
    "email": "test@example.com",
    "address": "Phnom Penh"
  }'
```

### Update Customer
```bash
curl -X PUT "https://api.gtvmotor.dev/v1/customers/1" \
  -H "X-API-Key: your_key" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Updated Name",
    "phone": "098765432"
  }'
```

### Delete Customer
```bash
curl -X DELETE "https://api.gtvmotor.dev/v1/customers/1" \
  -H "X-API-Key: your_key"
```

---

## ⚠️ Important Notes

### 1. **API Key Permissions**
- **Read-only keys** (`permissions: ['read']`) can only GET data
- **Write keys** (`permissions: ['read', 'write']`) can GET, POST, PUT, DELETE

### 2. **Safety Checks**
- Cannot delete customer with vehicles/services
- Cannot delete vehicle with services
- All operations validate data exists before modifying

### 3. **Data Validation**
- Required fields are validated
- Data is sanitized before database operations
- Timestamp suffixes are automatically removed (frontend compatibility)

### 4. **Error Handling**
- 400: Bad Request (missing/invalid data)
- 403: Forbidden (no write permission)
- 404: Not Found (resource doesn't exist)
- 409: Conflict (cannot delete due to dependencies)
- 405: Method Not Allowed (invalid HTTP method)

---

## ✅ What's Working Now

### Before:
- ✅ GET customers (list & individual)
- ✅ GET vehicles (list & individual)
- ✅ GET invoices (list & individual)
- ❌ No create/update/delete

### After:
- ✅ GET customers (list & individual)
- ✅ POST customers (create)
- ✅ PUT/PATCH customers (update)
- ✅ DELETE customers (delete)
- ✅ GET vehicles (list & individual)
- ✅ POST vehicles (create)
- ✅ PUT/PATCH vehicles (update)
- ✅ DELETE vehicles (delete)
- ✅ GET invoices (list & individual)
- ⚠️ Invoices remain read-only (for safety)

---

## 🎯 Next Steps (Optional)

If you want to add write methods to invoices:

1. **Create Service/Invoice:**
   - POST `/v1/invoices` - Create new service with items
   - Handle service_items creation
   - Generate invoice numbers
   - Calculate totals

2. **Update Service/Invoice:**
   - PUT `/v1/invoices/{id}` - Update service details
   - Handle service_items updates
   - Recalculate totals

3. **Delete Service/Invoice:**
   - DELETE `/v1/invoices/{id}` - Delete service
   - Handle service_items deletion
   - Consider soft delete vs hard delete

**Note:** Invoices are complex because they involve:
- Services table
- Service_items table
- Invoice number generation
- Total calculations
- Exchange rate handling

---

## 📝 Summary

✅ **API v1 is now FULL CRUD** for customers and vehicles
✅ **Write permissions** are enforced
✅ **Safety checks** prevent data loss
✅ **Data validation** ensures data integrity
⚠️ **Invoices remain read-only** (can be added later if needed)

Your API v1 is now production-ready for create, read, update, and delete operations! 🎉

