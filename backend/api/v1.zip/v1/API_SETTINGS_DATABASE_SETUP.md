# API Settings Database Setup Guide

## ✅ **YES, You Should Store API Settings in MySQL**

Storing API settings in the database provides:
- ✅ **Persistence** - Settings saved across sessions
- ✅ **Multi-device sync** - Same settings on all devices
- ✅ **Backup** - Settings included in database backups
- ✅ **Centralized management** - One place to manage settings

---

## 📋 **Step 1: Add API Settings to Database**

### Run This SQL Script:

```bash
mysql -u your_username -p your_database < backend/api/v1/add_api_settings_to_database.sql
```

**Or manually run:**

```sql
-- Add API settings to system_config table
INSERT INTO `system_config` (`config_key`, `config_value`, `config_type`, `description`, `created_at`, `updated_at`)
VALUES
('api_base_url', 'https://api.gtvmotor.dev/v1', 'string', 'API Base URL for all API requests', NOW(), NOW()),
('api_key', '', 'string', 'API key for authentication', NOW(), NOW()),
('api_timeout', '30000', 'number', 'Request timeout in milliseconds', NOW(), NOW()),
('api_retry_attempts', '3', 'number', 'Number of retry attempts for failed requests', NOW(), NOW()),
('api_cache_duration', '300', 'number', 'Cache duration in seconds', NOW(), NOW()),
('api_enable_caching', 'true', 'boolean', 'Enable API response caching', NOW(), NOW())
ON DUPLICATE KEY UPDATE
    `config_value` = VALUES(`config_value`),
    `updated_at` = NOW();
```

---

## 📊 **Database Structure**

The settings will be stored in the existing `system_config` table:

| Column | Type | Description |
|--------|------|-------------|
| `config_key` | varchar(100) | Setting key (e.g., 'api_base_url') |
| `config_value` | text | Setting value (e.g., 'https://api.gtvmotor.dev/v1') |
| `config_type` | enum | 'string', 'number', 'boolean', 'json' |
| `description` | text | Human-readable description |

**Example Records:**
```
api_base_url → https://api.gtvmotor.dev/v1
api_key → (your encrypted API key)
api_timeout → 30000
api_retry_attempts → 3
api_cache_duration → 300
api_enable_caching → true
```

---

## 🔧 **Step 2: Update Backend API**

The backend API endpoint (`backend/api/settings.php`) needs to handle API settings.

**Add this to handle API settings:**

```php
case 'api':
    // Get API settings from database
    $database = new Database();
    $db = $database->getConnection();

    $stmt = $db->prepare("
        SELECT config_key, config_value, config_type
        FROM system_config
        WHERE config_key LIKE 'api_%'
    ");
    $stmt->execute();
    $configs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $settings = [];
    foreach ($configs as $config) {
        $key = str_replace('api_', '', $config['config_key']);
        $value = $config['config_value'];

        // Convert based on type
        switch ($config['config_type']) {
            case 'number':
                $value = (int)$value;
                break;
            case 'boolean':
                $value = $value === 'true' || $value === '1';
                break;
        }

        $settings[$key] = $value;
    }

    // Format for frontend
    $settings = [
        'baseUrl' => $settings['base_url'] ?? 'https://api.gtvmotor.dev/v1',
        'apiKey' => $settings['key'] ?? '',
        'timeout' => $settings['timeout'] ?? '30000',
        'retryAttempts' => $settings['retry_attempts'] ?? '3',
        'cacheDuration' => $settings['cache_duration'] ?? '300',
        'enableCaching' => $settings['enable_caching'] ?? true
    ];
    break;
```

---

## 💾 **Step 3: Update Frontend to Save/Load**

### Update `app/settings/page.tsx`:

```typescript
// Load API settings on mount
useEffect(() => {
  const loadApiSettings = async () => {
    try {
      const response = await fetch('/api/settings?type=api');
      const data = await response.json();
      if (data.success && data.data) {
        setApiSettings({
          baseUrl: data.data.baseUrl || API_BASE_URL,
          apiKey: data.data.apiKey || '',
          timeout: String(data.data.timeout || 30000),
          retryAttempts: String(data.data.retryAttempts || 3),
          cacheDuration: String(data.data.cacheDuration || 300),
          enableCaching: data.data.enableCaching !== false
        });
      }
    } catch (error) {
      console.error('Failed to load API settings:', error);
    }
  };
  loadApiSettings();
}, []);

// Update save function
const handleSaveApiSettings = async () => {
  try {
    const response = await fetch('/api/settings?type=api', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        baseUrl: apiSettings.baseUrl,
        apiKey: apiSettings.apiKey,
        timeout: parseInt(apiSettings.timeout),
        retryAttempts: parseInt(apiSettings.retryAttempts),
        cacheDuration: parseInt(apiSettings.cacheDuration),
        enableCaching: apiSettings.enableCaching
      })
    });

    const data = await response.json();
    if (data.success) {
      toast({
        title: "Success",
        description: "API settings saved successfully"
      });
    }
  } catch (error) {
    toast({
      title: "Error",
      description: "Failed to save API settings",
      variant: "destructive"
    });
  }
};
```

---

## 🔐 **Security Note: API Key Storage**

**Important:** API keys should be stored securely:

1. **Option 1: Encrypt in Database** (Recommended)
   ```php
   // Encrypt before saving
   $encryptedKey = openssl_encrypt($apiKey, 'AES-256-CBC', $encryptionKey);

   // Decrypt when loading
   $apiKey = openssl_decrypt($encryptedKey, 'AES-256-CBC', $encryptionKey);
   ```

2. **Option 2: Store Hash Only**
   - Store hash of API key for validation
   - User must enter key each time (less convenient)

3. **Option 3: Environment Variables** (Most Secure)
   - Store API keys in `.env` file
   - Never commit to Git
   - Load from environment, not database

**For now:** Store in database (can encrypt later if needed)

---

## ✅ **Complete Setup Checklist**

1. ✅ **Run SQL Script**
   ```bash
   mysql -u username -p database < backend/api/v1/add_api_settings_to_database.sql
   ```

2. ✅ **Update Backend API** (`backend/api/settings.php`)
   - Add 'api' case to GET handler
   - Add POST handler to save API settings

3. ✅ **Update Frontend** (`app/settings/page.tsx`)
   - Load settings on mount
   - Save settings to database

4. ✅ **Test**
   - Save settings in form
   - Refresh page - settings should persist
   - Check database - values should be saved

---

## 📊 **Database Verification**

After setup, verify settings are stored:

```sql
SELECT config_key, config_value, config_type
FROM system_config
WHERE config_key LIKE 'api_%'
ORDER BY config_key;
```

**Expected Output:**
```
api_base_url        | https://api.gtvmotor.dev/v1 | string
api_cache_duration  | 300                         | number
api_enable_caching  | true                        | boolean
api_key             | (your key)                  | string
api_retry_attempts  | 3                           | number
api_timeout         | 30000                       | number
```

---

## 🎯 **Summary**

✅ **YES, store API settings in MySQL** for:
- Persistence across sessions
- Multi-device synchronization
- Centralized management
- Backup inclusion

**Next Steps:**
1. Run the SQL script
2. Update backend API
3. Update frontend to save/load
4. Test the functionality

Your API settings will now be stored securely in the database! 🎉

