<?php
/**
 * API v1 Column Validation Script
 * Checks if all columns used in API queries exist in the database
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

echo "\n";
echo "========================================\n";
echo "API v1 Column Validation Check\n";
echo "========================================\n\n";

try {
    $database = new Database();
    $db = $database->getConnection();

    // Columns used in API queries
    $apiColumns = [
        'customers' => ['id', 'name', 'phone', 'email', 'address', 'created_at', 'updated_at'],
        'vehicles' => ['id', 'customer_id', 'plate_number', 'vin_number', 'year', 'current_km', 'purchase_date', 'warranty_start_date', 'warranty_end_date', 'warranty_km_limit', 'warranty_service_count', 'warranty_max_services', 'vehicle_model_id', 'created_at', 'updated_at'],
        'services' => ['id', 'customer_id', 'vehicle_id', 'invoice_number', 'service_date', 'current_km', 'next_service_km', 'next_service_date', 'total_amount', 'payment_method', 'payment_status', 'service_status', 'notes', 'service_detail', 'exchange_rate', 'total_khr', 'volume_l', 'technician_id', 'sales_rep_id', 'service_type_id', 'created_at', 'updated_at'],
        'service_items' => ['id', 'service_id', 'description', 'quantity', 'unit_price', 'total_price', 'item_type', 'inventory_item_id', 'created_at', 'updated_at'],
        'vehicle_models' => ['id', 'name', 'category', 'base_price', 'description', 'cc_displacement', 'engine_type', 'fuel_type', 'transmission', 'warranty_km_limit', 'warranty_max_services'],
        'service_types' => ['id', 'service_type_name', 'category'],
        'staff' => ['id', 'name'],
        'warranties' => ['id', 'vehicle_id', 'warranty_type', 'start_date', 'end_date', 'km_limit', 'service_count', 'max_services', 'cost_covered']
    ];

    $errors = [];
    $warnings = [];
    $success = [];

    foreach ($apiColumns as $table => $columns) {
        echo "Checking table: {$table}\n";
        echo str_repeat('-', 50) . "\n";

        // Check if table exists
        $stmt = $db->prepare("
            SELECT COUNT(*) as count
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
            AND table_name = ?
        ");
        $stmt->execute([$table]);
        $tableExists = $stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;

        if (!$tableExists) {
            $errors[] = "Table '{$table}' does not exist!";
            echo "  ❌ Table does not exist!\n\n";
            continue;
        }

        // Check each column
        foreach ($columns as $column) {
            $stmt = $db->prepare("
                SELECT COUNT(*) as count
                FROM information_schema.columns
                WHERE table_schema = DATABASE()
                AND table_name = ?
                AND column_name = ?
            ");
            $stmt->execute([$table, $column]);
            $columnExists = $stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;

            if ($columnExists) {
                echo "  ✅ {$column}\n";
                $success[] = "{$table}.{$column}";
            } else {
                // Check if it's a critical column or optional
                $criticalColumns = ['id', 'created_at'];
                $optionalColumns = ['inventory_item_id', 'updated_at'];

                if (in_array($column, $criticalColumns)) {
                    $errors[] = "Critical column '{$table}.{$column}' is missing!";
                    echo "  ❌ {$column} - MISSING (CRITICAL)\n";
                } elseif (in_array($column, $optionalColumns)) {
                    $warnings[] = "Optional column '{$table}.{$column}' is missing (recommended to add)";
                    echo "  ⚠️  {$column} - MISSING (Optional but recommended)\n";
                } else {
                    $errors[] = "Column '{$table}.{$column}' is missing!";
                    echo "  ❌ {$column} - MISSING\n";
                }
            }
        }

        echo "\n";
    }

    // Summary
    echo "\n";
    echo "========================================\n";
    echo "Validation Summary\n";
    echo "========================================\n\n";

    if (empty($errors) && empty($warnings)) {
        echo "✅ ALL COLUMNS EXIST - API is 100% compatible!\n\n";
    } else {
        if (!empty($errors)) {
            echo "❌ ERRORS FOUND (" . count($errors) . "):\n";
            foreach ($errors as $error) {
                echo "   - {$error}\n";
            }
            echo "\n";
        }

        if (!empty($warnings)) {
            echo "⚠️  WARNINGS (" . count($warnings) . "):\n";
            foreach ($warnings as $warning) {
                echo "   - {$warning}\n";
            }
            echo "\n";
        }

        echo "✅ SUCCESSFUL CHECKS: " . count($success) . " columns\n\n";
    }

    // Recommendations
    if (!empty($warnings) || !empty($errors)) {
        echo "========================================\n";
        echo "Recommendations\n";
        echo "========================================\n\n";

        if (in_array('service_items.inventory_item_id', array_map(function($w) { return strpos($w, 'inventory_item_id') !== false ? 'service_items.inventory_item_id' : null; }, $warnings))) {
            echo "1. Run database update script to add missing columns:\n";
            echo "   mysql -u username -p database < backend/api/v1/update_database_minimal.sql\n\n";
        }

        if (!empty($errors)) {
            echo "2. Fix critical errors before using the API\n";
            echo "   Some columns are required for the API to work correctly.\n\n";
        }
    }

    echo "========================================\n";
    echo "Check Complete\n";
    echo "========================================\n\n";

} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "\n";
    exit(1);
}

?>

