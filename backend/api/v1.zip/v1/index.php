<?php
/**
 * API v1 Router
 * GTV Motor PHP Backend - Main Entry Point
 * Endpoint: api.gtvmotor.dev/v1/
 */

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to users
ini_set('log_errors', 1);

// Check if required files exist
$configPath = __DIR__ . '/../config/config.php';
$responsePath = __DIR__ . '/../includes/Response.php';
$v1ConfigPath = __DIR__ . '/config.php';

if (!file_exists($configPath)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Configuration file not found: ' . $configPath
    ]);
    exit;
}

if (!file_exists($responsePath)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Response class not found: ' . $responsePath
    ]);
    exit;
}

if (!file_exists($v1ConfigPath)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'API v1 config file not found: ' . $v1ConfigPath
    ]);
    exit;
}

try {
    require_once $configPath;
    require_once $responsePath;
    require_once $v1ConfigPath;
} catch (Exception $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Error loading required files: ' . $e->getMessage()
    ]);
    exit;
}

// Get request path
$uri = $_SERVER['REQUEST_URI'];
$path = parse_url($uri, PHP_URL_PATH);

// Remove base path if needed (handle both /v1 and /api/v1)
$basePath = '/api/v1';
if (strpos($path, $basePath) === 0) {
    $path = substr($path, strlen($basePath));
} else {
    $basePath = '/v1';
    if (strpos($path, $basePath) === 0) {
        $path = substr($path, strlen($basePath));
    }
}

// Remove leading/trailing slashes
$path = trim($path, '/');

// Split path into segments
$segments = explode('/', $path);
$segments = array_filter($segments);
$segments = array_values($segments);

// Route to appropriate endpoint
$endpoint = $segments[0] ?? '';

// API Information endpoint
if (empty($endpoint) || $endpoint === 'index.php') {
    Response::success([
        'api' => 'GTV Motor API',
        'version' => API_V1_VERSION,
        'base_url' => API_V1_BASE_URL,
        'endpoints' => [
            'customers' => API_V1_BASE_URL . 'customers',
            'vehicles' => API_V1_BASE_URL . 'vehicles',
            'invoices' => API_V1_BASE_URL . 'invoices',
            'analytics' => API_V1_BASE_URL . 'analytics'
        ],
        'documentation' => 'https://api.gtvmotor.dev/v1/docs',
        'authentication' => 'API Key required in X-API-Key header'
    ], 'GTV Motor API v1');
    exit;
}

// Route to endpoint files
$endpointFile = __DIR__ . '/' . $endpoint . '.php';

if (file_exists($endpointFile)) {
    require_once $endpointFile;
} else {
    Response::notFound('Endpoint not found. Available endpoints: customers, vehicles, invoices');
}

?>

