<?php
/**
 * API v1 Test Script
 * Test all API endpoints to ensure they work correctly
 * Usage: php test-api-endpoints.php
 */

// Configuration
$baseUrl = 'https://api.gtvmotor.dev/api/v1';
$apiKey = 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6'; // Default test key

echo "\n";
echo "========================================\n";
echo "GTV Motor API v1 - Endpoint Test\n";
echo "========================================\n\n";
echo "Base URL: {$baseUrl}\n";
echo "API Key: " . substr($apiKey, 0, 10) . "...\n\n";

$tests = [
    [
        'name' => 'API Info',
        'method' => 'GET',
        'url' => $baseUrl,
        'expected_status' => 200
    ],
    [
        'name' => 'Get Customers List',
        'method' => 'GET',
        'url' => $baseUrl . '/customers?limit=5',
        'expected_status' => 200
    ],
    [
        'name' => 'Get Vehicles List',
        'method' => 'GET',
        'url' => $baseUrl . '/vehicles?limit=5',
        'expected_status' => 200
    ],
    [
        'name' => 'Get Invoices List',
        'method' => 'GET',
        'url' => $baseUrl . '/invoices?limit=5',
        'expected_status' => 200
    ],
    [
        'name' => 'Get Analytics Overview',
        'method' => 'GET',
        'url' => $baseUrl . '/analytics?type=overview&days=7',
        'expected_status' => 200
    ],
];

$passed = 0;
$failed = 0;

foreach ($tests as $test) {
    echo "Testing: {$test['name']}\n";
    echo "  URL: {$test['url']}\n";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $test['url']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'X-API-Key: ' . $apiKey,
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        echo "  ❌ Error: {$error}\n";
        $failed++;
    } elseif ($httpCode == $test['expected_status']) {
        $data = json_decode($response, true);
        if ($data && isset($data['success'])) {
            echo "  ✅ Passed (HTTP {$httpCode})\n";
            if (isset($data['message'])) {
                echo "  Message: {$data['message']}\n";
            }
            $passed++;
        } else {
            echo "  ⚠️  Warning: Unexpected response format\n";
            echo "  Response: " . substr($response, 0, 100) . "...\n";
            $failed++;
        }
    } else {
        echo "  ❌ Failed: Expected HTTP {$test['expected_status']}, got {$httpCode}\n";
        if ($response) {
            $data = json_decode($response, true);
            if ($data && isset($data['error'])) {
                echo "  Error: {$data['error']}\n";
            }
        }
        $failed++;
    }

    echo "\n";
}

echo "========================================\n";
echo "Test Summary\n";
echo "========================================\n";
echo "Passed: {$passed}\n";
echo "Failed: {$failed}\n";
echo "Total: " . ($passed + $failed) . "\n\n";

if ($failed === 0) {
    echo "✅ All tests passed!\n";
} else {
    echo "⚠️  Some tests failed. Check the errors above.\n";
}

echo "\n";

?>

