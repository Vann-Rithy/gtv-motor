# API Analytics Setup Guide

## ✅ **YES - You Can Track API Traffic & Analytics!**

I've created a complete API analytics system that tracks all API requests and provides detailed analytics.

---

## 🚀 **Quick Setup (3 Steps)**

### **Step 1: Create Analytics Tables** (1 minute)

```bash
mysql -u your_username -p your_database < backend/api/v1/create_api_analytics_tables.sql
```

**This creates:**
- ✅ `api_requests` table - Stores every API request
- ✅ `api_analytics_summary` table - Pre-aggregated daily stats
- ✅ `api_performance_metrics` table - Performance tracking
- ✅ 5 Views for easy querying
- ✅ 2 Stored procedures for analytics

---

### **Step 2: Analytics is Already Integrated** ✅

The analytics tracking is already added to:
- ✅ `ApiAuth.php` - Starts tracking on every request
- ✅ All endpoints automatically log requests
- ✅ Response times, status codes, errors all tracked

**No action needed!**

---

### **Step 3: Access Analytics** (Ready to use)

**Analytics Endpoint:** `GET /v1/analytics?type=overview`

**Available Analytics Types:**
- `overview` - Overall statistics
- `endpoints` - Per-endpoint statistics
- `keys` - API key usage statistics
- `errors` - Error analysis
- `performance` - Performance metrics
- `traffic` - Hourly traffic (last 24 hours)

---

## 📊 **What Gets Tracked**

### **Every API Request Logs:**
- ✅ API key (partial, for security)
- ✅ Endpoint called
- ✅ HTTP method (GET, POST, PUT, DELETE)
- ✅ Status code (200, 404, 500, etc.)
- ✅ Response time (milliseconds)
- ✅ Request/Response size (bytes)
- ✅ IP address
- ✅ User agent
- ✅ Error messages (if any)
- ✅ Timestamp

---

## 🔍 **Available Analytics Views**

### **1. Overview Analytics**
```bash
GET /v1/analytics?type=overview&days=7
```

**Returns:**
- Total requests
- Successful/Failed requests
- Average response time
- Unique IPs, API keys, endpoints
- Daily breakdown

### **2. Endpoint Analytics**
```bash
GET /v1/analytics?type=endpoints&days=7
```

**Returns:**
- Requests per endpoint
- Success/error rates
- Average response times
- Error percentages

### **3. API Key Analytics**
```bash
GET /v1/analytics?type=keys&days=7
```

**Returns:**
- Usage per API key
- Endpoints used
- Unique IPs per key
- First/last request times

### **4. Error Analytics**
```bash
GET /v1/analytics?type=errors&days=7
```

**Returns:**
- Error codes and messages
- Affected endpoints
- Error frequency
- Last occurrence

### **5. Performance Analytics**
```bash
GET /v1/analytics?type=performance&days=7&endpoint=customers
```

**Returns:**
- Hourly performance metrics
- Average response times
- Min/Max response times
- Error rates

### **6. Traffic Analytics**
```bash
GET /v1/analytics?type=traffic
```

**Returns:**
- Hourly traffic (last 24 hours)
- Requests per hour
- Success/failure rates
- Unique IPs per hour

---

## 📋 **Database Views Available**

You can also query directly in MySQL:

### **View: Traffic Overview**
```sql
SELECT * FROM v_api_traffic_overview;
```

### **View: Usage by Endpoint**
```sql
SELECT * FROM v_api_usage_by_endpoint;
```

### **View: Usage by API Key**
```sql
SELECT * FROM v_api_usage_by_key;
```

### **View: Error Analysis**
```sql
SELECT * FROM v_api_errors;
```

### **View: Performance Trends**
```sql
SELECT * FROM v_api_performance_trends;
```

---

## 🧪 **Test Analytics**

### **1. Make Some API Requests**
```bash
curl -X GET "https://api.gtvmotor.dev/v1/customers" \
  -H "X-API-Key: your_key"

curl -X GET "https://api.gtvmotor.dev/v1/vehicles" \
  -H "X-API-Key: your_key"
```

### **2. Check Analytics**
```bash
curl -X GET "https://api.gtvmotor.dev/v1/analytics?type=overview&days=1" \
  -H "X-API-Key: your_key"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "overview": {
      "total_requests": 10,
      "successful_requests": 8,
      "failed_requests": 2,
      "avg_response_time_ms": 45.5,
      "unique_ips": 3,
      "unique_api_keys": 1
    },
    "by_day": [...]
  }
}
```

---

## 📊 **Example Analytics Queries**

### **Top 10 Most Used Endpoints**
```sql
SELECT endpoint, COUNT(*) as requests
FROM api_requests
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY endpoint
ORDER BY requests DESC
LIMIT 10;
```

### **Average Response Time by Endpoint**
```sql
SELECT
    endpoint,
    ROUND(AVG(response_time_ms), 2) as avg_ms,
    COUNT(*) as requests
FROM api_requests
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY endpoint
ORDER BY avg_ms DESC;
```

### **Error Rate by Endpoint**
```sql
SELECT
    endpoint,
    COUNT(*) as total,
    SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as errors,
    ROUND(SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as error_rate
FROM api_requests
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY endpoint
ORDER BY error_rate DESC;
```

---

## 🎯 **Features**

✅ **Automatic Tracking** - All requests logged automatically
✅ **Real-time Analytics** - Query current stats anytime
✅ **Performance Metrics** - Response times, error rates
✅ **Usage Statistics** - Per endpoint, per API key
✅ **Error Analysis** - Track and analyze errors
✅ **Traffic Patterns** - Hourly/daily trends
✅ **Database Views** - Easy SQL queries
✅ **Stored Procedures** - Pre-built analytics queries

---

## 📝 **Summary**

✅ **Analytics System:** Complete and ready
✅ **Database Tables:** Created with SQL script
✅ **Tracking:** Automatic on all requests
✅ **Analytics Endpoint:** `/v1/analytics`
✅ **Views:** 5 pre-built views for queries

**Just run the SQL script and analytics will start tracking automatically!** 🎉

