-- =====================================================
-- Minimal Database Update Script for API v1
-- Based on your actual database: gtvmnwkc_db (2).sql
-- This script ONLY adds missing columns
-- =====================================================

-- =====================================================
-- ANALYSIS RESULTS:
-- =====================================================
-- ✅ services table:
--    - exchange_rate: EXISTS (line 584)
--    - total_khr: EXISTS (line 585)
--    - volume_l: EXISTS (line 570)
--    - Indexes: ALL EXIST (lines 1691-1693)
--
-- ❌ service_items table:
--    - inventory_item_id: MISSING
--    - updated_at: MISSING
--
-- ✅ customers table: CLEAN (no duplicate columns)
-- ✅ vehicles table: CLEAN (no duplicate columns)
-- =====================================================

-- =====================================================
-- 1. SERVICE_ITEMS TABLE UPDATES (Only missing columns)
-- =====================================================

-- Add inventory_item_id column if it doesn't exist
SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'service_items'
    AND column_name = 'inventory_item_id'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE `service_items` ADD COLUMN `inventory_item_id` int(11) DEFAULT NULL COMMENT ''Reference to inventory_items table'' AFTER `item_type`',
    'SELECT "Column inventory_item_id already exists" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add updated_at column if it doesn't exist
SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'service_items'
    AND column_name = 'updated_at'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE `service_items` ADD COLUMN `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() AFTER `created_at`',
    'SELECT "Column updated_at already exists" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 2. VERIFICATION
-- =====================================================

-- Verify service_items table structure
SELECT
    'SERVICE_ITEMS TABLE - NEW COLUMNS' as info,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM information_schema.columns
WHERE table_schema = DATABASE()
AND table_name = 'service_items'
AND column_name IN ('inventory_item_id', 'updated_at')
ORDER BY ORDINAL_POSITION;

-- Verify all required columns for API
SELECT
    'API REQUIRED COLUMNS CHECK' as info,
    'services.exchange_rate' as column_name,
    CASE WHEN COUNT(*) > 0 THEN 'EXISTS' ELSE 'MISSING' END as status
FROM information_schema.columns
WHERE table_schema = DATABASE()
AND table_name = 'services'
AND column_name = 'exchange_rate'

UNION ALL

SELECT
    'API REQUIRED COLUMNS CHECK' as info,
    'services.total_khr' as column_name,
    CASE WHEN COUNT(*) > 0 THEN 'EXISTS' ELSE 'MISSING' END as status
FROM information_schema.columns
WHERE table_schema = DATABASE()
AND table_name = 'services'
AND column_name = 'total_khr'

UNION ALL

SELECT
    'API REQUIRED COLUMNS CHECK' as info,
    'services.volume_l' as column_name,
    CASE WHEN COUNT(*) > 0 THEN 'EXISTS' ELSE 'MISSING' END as status
FROM information_schema.columns
WHERE table_schema = DATABASE()
AND table_name = 'services'
AND column_name = 'volume_l'

UNION ALL

SELECT
    'API REQUIRED COLUMNS CHECK' as info,
    'service_items.inventory_item_id' as column_name,
    CASE WHEN COUNT(*) > 0 THEN 'EXISTS' ELSE 'MISSING' END as status
FROM information_schema.columns
WHERE table_schema = DATABASE()
AND table_name = 'service_items'
AND column_name = 'inventory_item_id'

UNION ALL

SELECT
    'API REQUIRED COLUMNS CHECK' as info,
    'service_items.updated_at' as column_name,
    CASE WHEN COUNT(*) > 0 THEN 'EXISTS' ELSE 'MISSING' END as status
FROM information_schema.columns
WHERE table_schema = DATABASE()
AND table_name = 'service_items'
AND column_name = 'updated_at';

-- =====================================================
-- SCRIPT COMPLETE
-- =====================================================

SELECT 'Database update completed! Only missing columns were added.' as status;

