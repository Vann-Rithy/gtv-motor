# API Configuration Review & Database Update Status

## 📊 Database Update Status

### ✅ **YES, Database Update is Needed** (Minimal - Only 2 Columns)

**Status:** ⚠️ **Required Update**

The `service_items` table is missing 2 columns needed for the API:

1. ❌ `inventory_item_id` (int, nullable) - Reference to inventory items
2. ❌ `updated_at` (timestamp) - Update timestamp

**Action Required:**
```bash
# Run this SQL script on your database
mysql -u your_username -p your_database < backend/api/v1/update_database_minimal.sql
```

**What's Already Good:**
- ✅ `services` table - All columns exist (exchange_rate, total_khr, volume_l)
- ✅ `customers` table - Clean, no duplicates
- ✅ `vehicles` table - Clean, no duplicates

**Impact:** Without these columns, the API will work but may have issues with:
- Inventory tracking for service items
- Proper update timestamps

---

## 🔧 Frontend API Configuration Review

### Your Current Settings:

| Setting | Value | Status | Notes |
|---------|-------|--------|-------|
| **API Base URL** | `https://api.gtvmotor.dev` | ⚠️ **Needs Fix** | Should include `/v1/` |
| **API Key** | (User enters) | ✅ **Correct** | Must match key in `backend/api/v1/config.php` |
| **Request Timeout** | `30000ms` (30s) | ✅ **Good** | Reasonable timeout |
| **Retry Attempts** | `3` | ✅ **Correct** | Matches backend config |
| **Cache Duration** | `300s` (5 min) | ✅ **Good** | Good for performance |
| **Enable API Caching** | `Enabled` | ✅ **Good** | Improves performance |

### ⚠️ Issues Found:

#### 1. **API Base URL Missing `/v1/`**

**Current:** `https://api.gtvmotor.dev`
**Should be:** `https://api.gtvmotor.dev/v1/`

**Why:** The API v1 endpoints are at `/v1/`, not the root.

**Fix:** Update the base URL in your settings form to:
```
https://api.gtvmotor.dev/v1
```

#### 2. **Settings Not Connected to API Client**

The settings form saves values, but `lib/api-client.ts` uses hardcoded values:
- Default timeout: `20000ms` (20s) - Your form has `30000ms`
- Base URL: Hardcoded in constructor

**Recommendation:** Connect the settings form to actually update the API client configuration.

---

## ✅ Correct Configuration Values

### Recommended Settings:

```javascript
{
  baseUrl: "https://api.gtvmotor.dev/v1",  // ← Add /v1
  apiKey: "your_generated_api_key_here",    // ← From backend/api/v1/config.php
  timeout: 30000,                            // ✅ 30 seconds (good)
  retryAttempts: 3,                          // ✅ Correct
  enableCaching: true,                       // ✅ Good
  cacheDuration: 300                          // ✅ 5 minutes (good)
}
```

### API Key Setup:

1. **Generate API Key:**
   ```bash
   php backend/api/v1/generate-api-key.php
   ```

2. **Add to Backend Config:**
   Edit `backend/api/v1/config.php` and add your generated key:
   ```php
   'your_generated_key_here' => [
       'name' => 'Frontend API Key',
       'permissions' => ['read', 'write'],
       'rate_limit' => 1000,
       'active' => true
   ],
   ```

3. **Enter in Frontend Settings:**
   - Go to Settings → API Configuration
   - Paste the generated key
   - Save

---

## 🔍 Configuration Comparison

### Frontend vs Backend:

| Setting | Frontend Form | Backend Config | Status |
|---------|---------------|----------------|--------|
| Base URL | `api.gtvmotor.dev` | `api.gtvmotor.dev/v1/` | ⚠️ Mismatch |
| Timeout | 30000ms | N/A (PHP handles) | ✅ OK |
| Retry | 3 | N/A (Frontend) | ✅ OK |
| Cache | 300s | N/A (Frontend) | ✅ OK |
| API Key | User input | `API_V1_KEYS` array | ✅ Must match |

---

## 📋 Action Items

### Immediate Actions:

1. ✅ **Fix API Base URL**
   - Change from: `https://api.gtvmotor.dev`
   - Change to: `https://api.gtvmotor.dev/v1`

2. ✅ **Run Database Update**
   ```bash
   mysql -u username -p database_name < backend/api/v1/update_database_minimal.sql
   ```

3. ✅ **Generate & Configure API Key**
   - Generate key using `generate-api-key.php`
   - Add to `backend/api/v1/config.php`
   - Enter in frontend settings form

### Optional Improvements:

4. 🔄 **Connect Settings to API Client**
   - Make settings form actually update `api-client.ts` configuration
   - Store settings in localStorage or backend
   - Apply timeout, retry, and cache settings dynamically

---

## ✅ Verification Checklist

After making changes, verify:

- [ ] Database update script executed successfully
- [ ] `service_items` table has `inventory_item_id` column
- [ ] `service_items` table has `updated_at` column
- [ ] API Base URL includes `/v1/`
- [ ] API Key generated and added to backend config
- [ ] API Key entered in frontend settings
- [ ] Test API call works: `GET /v1/customers` with API key

---

## 🧪 Test Your Configuration

### Test API Connection:

```bash
curl -X GET "https://api.gtvmotor.dev/v1/customers" \
  -H "X-API-Key: your_api_key_here"
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Customers retrieved successfully",
  "data": [...],
  "pagination": {...}
}
```

### Test with Frontend:

1. Open browser console
2. Navigate to Settings → API Configuration
3. Enter correct base URL: `https://api.gtvmotor.dev/v1`
4. Enter API key
5. Save settings
6. Test by loading customers page

---

## 📝 Summary

### Database: ⚠️ **Update Required**
- Run `update_database_minimal.sql` to add 2 missing columns

### API Configuration: ⚠️ **Needs Fix**
- ✅ Most settings are correct
- ⚠️ **Fix:** Add `/v1/` to API Base URL
- ✅ API Key, Timeout, Retry, Cache settings are good

### Next Steps:
1. Fix API Base URL (add `/v1/`)
2. Run database update script
3. Generate and configure API key
4. Test API connection

---

## 📞 Need Help?

- Check `backend/api/v1/API_KEY_GUIDE.md` for API key setup
- Check `backend/api/v1/API_PROCESS_FLOW.md` for API process details
- Check `backend/api/v1/DATABASE_CHECK_REPORT.md` for database details

