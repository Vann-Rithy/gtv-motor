# Quick Fix for HTTP 500 Error

## ✅ **Updated Files**

I've updated `index.php` with better error handling that will show you exactly what's wrong.

## 🔧 **Steps to Fix**

### **Step 1: Upload Updated Files**

Upload these updated files to your server:
- `backend/api/v1/index.php` (updated with error handling)
- `backend/api/v1/.htaccess` (updated RewriteBase)
- `backend/api/v1/debug.php` (new - for debugging)

### **Step 2: Check Error Message**

After uploading, visit: `https://api.gtvmotor.dev/api/v1/`

You should now see a JSON error message telling you exactly what's missing, for example:
```json
{
  "success": false,
  "error": "Configuration file not found: /path/to/config.php"
}
```

### **Step 3: Run Debug Script**

Visit: `https://api.gtvmotor.dev/api/v1/debug.php`

This will show you:
- ✅ Which files exist
- ✅ Which files are missing
- ✅ PHP version
- ✅ File paths
- ✅ Any errors loading files

### **Step 4: Common Fixes**

#### **If you see "Configuration file not found":**
- Make sure `/config/config.php` exists
- Check the file path matches your server structure

#### **If you see "Response class not found":**
- Make sure `/includes/Response.php` exists
- Verify the file path

#### **If you see "API v1 config file not found":**
- Make sure `/api/v1/config.php` exists
- This file should be in the same directory as `index.php`

### **Step 5: Verify File Structure**

Your server should have this structure:
```
/
├── config/
│   ├── config.php
│   └── database.php
├── includes/
│   └── Response.php
└── api/
    └── v1/
        ├── index.php
        ├── config.php
        ├── .htaccess
        ├── customers.php
        ├── vehicles.php
        ├── invoices.php
        ├── analytics.php
        └── middleware/
            └── ApiAuth.php
```

### **Step 6: Check .htaccess**

The `.htaccess` file has been updated to use `/api/v1/` as the RewriteBase.

If you're using cPanel, make sure:
- `.htaccess` file is uploaded
- File permissions allow Apache to read it
- `mod_rewrite` is enabled

## 🧪 **Test**

After uploading, test:
1. `https://api.gtvmotor.dev/api/v1/` - Should show API info or specific error
2. `https://api.gtvmotor.dev/api/v1/debug.php` - Should show debug info

## 📝 **Next Steps**

1. Upload the updated files
2. Check the error message (it will tell you what's wrong)
3. Fix any missing files
4. Test again

**The updated `index.php` will now tell you exactly what's causing the 500 error!** 🎯

