# Quick Setup Guide - API Settings in MySQL

## ✅ **YES - Store API Settings in MySQL**

Your API configuration settings should be stored in MySQL database for persistence.

---

## 🚀 **Quick Setup (3 Steps)**

### **Step 1: Run SQL Script** (30 seconds)

```bash
mysql -u your_username -p your_database < backend/api/v1/add_api_settings_to_database.sql
```

**This creates 6 settings in `system_config` table:**
- `api_base_url` → `https://api.gtvmotor.dev/v1`
- `api_key` → (empty, you'll enter it)
- `api_timeout` → `30000`
- `api_retry_attempts` → `3`
- `api_cache_duration` → `300`
- `api_enable_caching` → `true`

---

### **Step 2: Backend is Already Updated** ✅

The `backend/api/settings.php` file has been updated to:
- ✅ Load API settings from database
- ✅ Save API settings to database

**No action needed!**

---

### **Step 3: Update Frontend** (2 minutes)

Update `app/settings/page.tsx` to load and save from database:

```typescript
// Add this import at top
import { useEffect } from "react"
import { useToast } from "@/hooks/use-toast"

// Add this inside component (after state declarations)
const { toast } = useToast()

// Load settings on mount
useEffect(() => {
  const loadApiSettings = async () => {
    try {
      const response = await fetch('/api/settings?type=api');
      const data = await response.json();
      if (data.success && data.data) {
        setApiSettings({
          baseUrl: data.data.baseUrl || API_BASE_URL,
          apiKey: data.data.apiKey || '',
          timeout: String(data.data.timeout || 30000),
          retryAttempts: String(data.data.retryAttempts || 3),
          cacheDuration: String(data.data.cacheDuration || 300),
          enableCaching: data.data.enableCaching !== false
        });
      }
    } catch (error) {
      console.error('Failed to load API settings:', error);
    }
  };
  loadApiSettings();
}, []);

// Update save function
const handleSaveApiSettings = async () => {
  try {
    const response = await fetch('/api/settings?type=api', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        baseUrl: apiSettings.baseUrl,
        apiKey: apiSettings.apiKey,
        timeout: parseInt(apiSettings.timeout),
        retryAttempts: parseInt(apiSettings.retryAttempts),
        cacheDuration: parseInt(apiSettings.cacheDuration),
        enableCaching: apiSettings.enableCaching
      })
    });

    const data = await response.json();
    if (data.success) {
      toast({
        title: "Success",
        description: "API settings saved successfully"
      });
    } else {
      throw new Error(data.error || 'Failed to save');
    }
  } catch (error) {
    toast({
      title: "Error",
      description: "Failed to save API settings",
      variant: "destructive"
    });
  }
};
```

---

## ✅ **What This Gives You**

1. ✅ **Persistence** - Settings saved across browser sessions
2. ✅ **Multi-device** - Same settings on all devices
3. ✅ **Backup** - Settings included in database backups
4. ✅ **Centralized** - One place to manage all API settings

---

## 🧪 **Test It**

1. **Save settings** in the form
2. **Refresh page** - settings should load automatically
3. **Check database:**
   ```sql
   SELECT * FROM system_config WHERE config_key LIKE 'api_%';
   ```

---

## 📊 **Database Structure**

Settings stored in `system_config` table:

| config_key | config_value | config_type |
|------------|--------------|-------------|
| `api_base_url` | `https://api.gtvmotor.dev/v1` | string |
| `api_key` | `your_key_here` | string |
| `api_timeout` | `30000` | number |
| `api_retry_attempts` | `3` | number |
| `api_cache_duration` | `300` | number |
| `api_enable_caching` | `true` | boolean |

---

## 🎯 **Summary**

✅ **YES** - Store API settings in MySQL
✅ **Backend** - Already updated
✅ **Frontend** - Just add load/save code
✅ **Database** - Run SQL script

**Total Time:** ~5 minutes

Your API settings will now persist in the database! 🎉

