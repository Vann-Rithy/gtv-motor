<?php
/**
 * API Key Generator
 * GTV Motor PHP Backend - Generate secure API keys
 *
 * Usage: php generate-api-key.php
 */

echo "\n";
echo "========================================\n";
echo "GTV Motor API v1 - Key Generator\n";
echo "========================================\n\n";

// Method 1: Generate from secret string
echo "Method 1: Generate from secret string\n";
echo "----------------------------------------\n";
$secret = 'gtvmotor_production_secret_' . date('Y');
$apiKey1 = hash('sha256', $secret);
echo "Secret: $secret\n";
echo "API Key: $apiKey1\n";
echo "Length: " . strlen($apiKey1) . " characters\n\n";

// Method 2: Generate with unique ID
echo "Method 2: Generate with unique ID\n";
echo "----------------------------------------\n";
$uniqueSecret = 'gtvmotor_' . uniqid() . '_' . time();
$apiKey2 = hash('sha256', $uniqueSecret);
echo "Secret: $uniqueSecret\n";
echo "API Key: $apiKey2\n";
echo "Length: " . strlen($apiKey2) . " characters\n\n";

// Method 3: Generate random key
echo "Method 3: Generate random key\n";
echo "----------------------------------------\n";
$randomBytes = random_bytes(32);
$apiKey3 = bin2hex($randomBytes);
echo "API Key: $apiKey3\n";
echo "Length: " . strlen($apiKey3) . " characters\n\n";

// Method 4: Generate with custom prefix
echo "Method 4: Generate with custom prefix\n";
echo "----------------------------------------\n";
$prefix = 'gtv_api_';
$customSecret = $prefix . date('Ymd') . '_' . bin2hex(random_bytes(16));
$apiKey4 = hash('sha256', $customSecret);
echo "Secret: $customSecret\n";
echo "API Key: $apiKey4\n";
echo "Length: " . strlen($apiKey4) . " characters\n\n";

echo "========================================\n";
echo "Configuration Example:\n";
echo "========================================\n\n";
echo "Add to backend/api/v1/config.php:\n\n";
echo "'$apiKey1' => [\n";
echo "    'name' => 'Production API Key',\n";
echo "    'permissions' => ['read', 'write'],\n";
echo "    'rate_limit' => 1000,\n";
echo "    'active' => true\n";
echo "],\n\n";

echo "========================================\n";
echo "Test Your API Key:\n";
echo "========================================\n\n";
echo "curl -X GET \"https://api.gtvmotor.dev/v1/\" \\\n";
echo "  -H \"X-API-Key: $apiKey1\"\n\n";

echo "========================================\n";
echo "Done!\n";
echo "========================================\n\n";

?>

