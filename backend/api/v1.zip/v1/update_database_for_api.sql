-- =====================================================
-- Database Update Script for API v1
-- GTV Motor PHP Backend
-- This script adds missing columns required by the API
-- =====================================================

-- =====================================================
-- 1. SERVICES TABLE UPDATES
-- =====================================================

-- Add exchange_rate column if it doesn't exist
SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'services'
    AND column_name = 'exchange_rate'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE `services` ADD COLUMN `exchange_rate` decimal(8,2) DEFAULT NULL COMMENT ''Exchange rate USD to KHR (user input required)'' AFTER `service_cost`',
    'SELECT "Column exchange_rate already exists" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add total_khr column if it doesn't exist
SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'services'
    AND column_name = 'total_khr'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE `services` ADD COLUMN `total_khr` decimal(12,2) DEFAULT NULL COMMENT ''Total amount in KHR'' AFTER `exchange_rate`',
    'SELECT "Column total_khr already exists" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add volume_l column if it doesn't exist
SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'services'
    AND column_name = 'volume_l'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE `services` ADD COLUMN `volume_l` decimal(5,2) DEFAULT NULL COMMENT ''Engine volume in liters'' AFTER `current_km`',
    'SELECT "Column volume_l already exists" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add indexes for better performance
SET @idx_exists = (
    SELECT COUNT(*)
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
    AND table_name = 'services'
    AND index_name = 'idx_exchange_rate'
);

SET @sql = IF(@idx_exists = 0,
    'ALTER TABLE `services` ADD INDEX `idx_exchange_rate` (`exchange_rate`)',
    'SELECT "Index idx_exchange_rate already exists" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @idx_exists = (
    SELECT COUNT(*)
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
    AND table_name = 'services'
    AND index_name = 'idx_total_khr'
);

SET @sql = IF(@idx_exists = 0,
    'ALTER TABLE `services` ADD INDEX `idx_total_khr` (`total_khr`)',
    'SELECT "Index idx_total_khr already exists" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 2. SERVICE_ITEMS TABLE UPDATES
-- =====================================================

-- Add inventory_item_id column if it doesn't exist
SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'service_items'
    AND column_name = 'inventory_item_id'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE `service_items` ADD COLUMN `inventory_item_id` int(11) DEFAULT NULL COMMENT ''Reference to inventory_items table'' AFTER `item_type`',
    'SELECT "Column inventory_item_id already exists" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add updated_at column if it doesn't exist
SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'service_items'
    AND column_name = 'updated_at'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE `service_items` ADD COLUMN `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() AFTER `created_at`',
    'SELECT "Column updated_at already exists" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 3. CUSTOMERS TABLE CLEANUP (if needed)
-- =====================================================

-- Remove duplicate columns if they exist (customer_name, customer_email, customer_address)
-- These are not needed as we have name, email, address columns

SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'customers'
    AND column_name = 'customer_name'
);

SET @sql = IF(@col_exists > 0,
    'ALTER TABLE `customers` DROP COLUMN `customer_name`',
    'SELECT "Column customer_name does not exist" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'customers'
    AND column_name = 'customer_email'
);

SET @sql = IF(@col_exists > 0,
    'ALTER TABLE `customers` DROP COLUMN `customer_email`',
    'SELECT "Column customer_email does not exist" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'customers'
    AND column_name = 'customer_address'
);

SET @sql = IF(@col_exists > 0,
    'ALTER TABLE `customers` DROP COLUMN `customer_address`',
    'SELECT "Column customer_address does not exist" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 4. VEHICLES TABLE CLEANUP (if needed)
-- =====================================================

-- Remove duplicate vehicle_plate column if it exists (we have plate_number)
SET @col_exists = (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
    AND table_name = 'vehicles'
    AND column_name = 'vehicle_plate'
);

SET @sql = IF(@col_exists > 0,
    'ALTER TABLE `vehicles` DROP COLUMN `vehicle_plate`',
    'SELECT "Column vehicle_plate does not exist" as message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 5. VERIFICATION QUERIES
-- =====================================================

-- Verify services table structure
SELECT
    'SERVICES TABLE COLUMNS' as info,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM information_schema.columns
WHERE table_schema = DATABASE()
AND table_name = 'services'
AND column_name IN ('exchange_rate', 'total_khr', 'volume_l')
ORDER BY ORDINAL_POSITION;

-- Verify service_items table structure
SELECT
    'SERVICE_ITEMS TABLE COLUMNS' as info,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM information_schema.columns
WHERE table_schema = DATABASE()
AND table_name = 'service_items'
AND column_name IN ('inventory_item_id', 'updated_at')
ORDER BY ORDINAL_POSITION;

-- =====================================================
-- 6. UPDATE EXISTING DATA (Optional)
-- =====================================================

-- Set default values for existing records (if columns were just added)
-- Uncomment if you want to set default values for existing NULL records

-- UPDATE `services`
-- SET `exchange_rate` = 0.00
-- WHERE `exchange_rate` IS NULL;

-- UPDATE `services`
-- SET `total_khr` = 0.00
-- WHERE `total_khr` IS NULL;

-- =====================================================
-- SCRIPT COMPLETE
-- =====================================================

SELECT 'Database update completed successfully!' as status;

