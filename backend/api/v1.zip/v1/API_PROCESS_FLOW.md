# API Process Flow - Complete Guide

## 🔄 Complete API Request Process

### Step-by-Step Flow

```
┌─────────────────────────────────────────────────────────┐
│                   1. CLIENT REQUEST                     │
│  Client sends HTTP request with API key in header       │
│  Example: GET /v1/customers                            │
│  Header: X-API-Key: your_api_key_here                  │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│             2. API ROUTER (index.php)                   │
│  - Receives request                                     │
│  - Parses URL path                                      │
│  - Routes to appropriate endpoint                       │
│  Example: /v1/customers → customers.php                 │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│        3. ENDPOINT FILE (e.g., customers.php)            │
│  - Loads configuration                                  │
│  - Loads database connection                            │
│  - Calls authentication middleware                      │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│        4. AUTHENTICATION (ApiAuth::validateApiKey)      │
│                                                          │
│  Step 4.1: Extract API Key                              │
│  ├─ Check X-API-Key header                              │
│  ├─ Check Authorization: Bearer header                 │
│  ├─ Check Authorization: ApiKey header                 │
│  └─ Check ?api_key query parameter (fallback)           │
│                                                          │
│  Step 4.2: Validate API Key                             │
│  ├─ Check if key exists in API_V1_KEYS                  │
│  ├─ Check if key is active                              │
│  └─ Return key configuration                            │
│                                                          │
│  Step 4.3: Check Rate Limit                              │
│  ├─ Read rate limit file                                │
│  ├─ Check current hour                                  │
│  ├─ Check request count                                 │
│  ├─ Compare with limit                                  │
│  └─ Increment counter if within limit                   │
│                                                          │
│  Step 4.4: Log Request                                  │
│  ├─ Create log entry                                    │
│  ├─ Save to api_v1.log                                  │
│  └─ Include: timestamp, method, URI, IP, user agent     │
│                                                          │
│  Step 4.5: Check Permissions                             │
│  ├─ Verify 'read' permission for GET                    │
│  ├─ Verify 'write' permission for POST/PUT/DELETE       │
│  └─ Return key config if all checks pass                │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│        5. DATABASE QUERY                                 │
│  - Connect to database                                  │
│  - Prepare SQL query                                    │
│  - Execute with parameters                              │
│  - Fetch results                                        │
│  - Join related tables (customers, vehicles, etc.)      │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│        6. DATA PROCESSING                                │
│  - Format response data                                 │
│  - Add related data (vehicles, services)                │
│  - Calculate totals/statistics                          │
│  - Apply pagination                                     │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│        7. RESPONSE FORMATTING                            │
│  - Create JSON response                                 │
│  - Add success/error status                             │
│  - Add pagination data (if applicable)                  │
│  - Add timestamp                                        │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│        8. RETURN RESPONSE                                │
│  - Set HTTP status code                                 │
│  - Set Content-Type: application/json                   │
│  - Return JSON to client                                │
└─────────────────────────────────────────────────────────┘
```

## 🔐 Authentication Process Details

### API Key Extraction Priority

1. **X-API-Key Header** (Highest Priority)
   ```
   X-API-Key: your_api_key_here
   ```

2. **Authorization: Bearer**
   ```
   Authorization: Bearer your_api_key_here
   ```

3. **Authorization: ApiKey**
   ```
   Authorization: ApiKey your_api_key_here
   ```

4. **Query Parameter** (Lowest Priority - Less Secure)
   ```
   ?api_key=your_api_key_here
   ```

### Validation Steps

```php
// Step 1: Get API Key
$apiKey = getApiKey(); // From headers or query

// Step 2: Check if exists
if (!isset(API_V1_KEYS[$apiKey])) {
    return error('Invalid API key');
}

// Step 3: Check if active
$keyConfig = API_V1_KEYS[$apiKey];
if (!$keyConfig['active']) {
    return error('API key is inactive');
}

// Step 4: Check rate limit
if (rateLimitExceeded($apiKey, $keyConfig['rate_limit'])) {
    return error('Rate limit exceeded');
}

// Step 5: Check permissions
if (!hasPermission($keyConfig, 'read')) {
    return error('Permission denied');
}

// Step 6: Log request
logRequest($apiKey);

// Step 7: Allow request
return $keyConfig;
```

## 📊 Rate Limiting Process

### How Rate Limiting Works

```
Request comes in
    ↓
Check rate limit file: rate_limit_[key_hash].json
    ↓
Read current hour and count
    ↓
Is current hour same as stored hour?
    ├─ YES → Use existing count
    └─ NO  → Reset count to 0
    ↓
Is count < limit?
    ├─ YES → Increment count, allow request
    └─ NO  → Return 429 error
    ↓
Save updated count to file
```

### Rate Limit File Structure

**File:** `backend/logs/rate_limit_[md5_hash_of_key].json`

```json
{
  "hour": "2024-10-01-14",
  "count": 245
}
```

- **hour**: Current hour in format `YYYY-MM-DD-HH`
- **count**: Number of requests in this hour
- **Auto-reset**: When hour changes, count resets to 0

## 📝 Request Logging Process

### Log File Location

**File:** `backend/logs/api_v1.log`

### Log Entry Format

```json
{
  "timestamp": "2024-10-01 14:30:45",
  "api_key": "a1b2c3d4e...",
  "method": "GET",
  "uri": "/v1/customers?page=1",
  "ip": "192.168.1.100",
  "user_agent": "Mozilla/5.0..."
}
```

### Log Rotation

- Logs are appended to file
- No automatic rotation (configure server-level rotation)
- Partial API key shown (first 10 chars) for security

## 🔄 Complete Example Request

### Request

```http
GET /v1/customers/1 HTTP/1.1
Host: api.gtvmotor.dev
X-API-Key: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6
Content-Type: application/json
```

### Process

1. **Router** receives request → routes to `customers.php`
2. **customers.php** loads → calls `ApiAuth::validateApiKey()`
3. **ApiAuth** extracts key from `X-API-Key` header
4. **ApiAuth** validates key exists in `API_V1_KEYS`
5. **ApiAuth** checks key is active → ✅
6. **ApiAuth** checks rate limit → ✅ (245/1000)
7. **ApiAuth** checks permissions → ✅ (has 'read')
8. **ApiAuth** logs request → saved to `api_v1.log`
9. **customers.php** queries database → gets customer data
10. **customers.php** formats response → JSON
11. **Response** returned to client

### Response

```json
{
  "success": true,
  "message": "Customer information retrieved successfully",
  "data": {
    "id": 1,
    "name": "Poeng Lim",
    "phone": "883176894",
    "email": "poenglim@email.com",
    "address": "Phnom Penh",
    "vehicles": [...],
    "services": [...],
    "vehicle_count": 1,
    "service_count": 2,
    "total_spent": 450.00
  },
  "timestamp": "2024-10-01T14:30:45+00:00"
}
```

## 🛡️ Security Features

### 1. API Key Validation
- ✅ Key must exist in configuration
- ✅ Key must be active
- ✅ Key is checked on every request

### 2. Rate Limiting
- ✅ Prevents abuse
- ✅ Per-key limits
- ✅ Hourly reset

### 3. Permission System
- ✅ Read-only keys
- ✅ Read-write keys
- ✅ Granular control

### 4. Request Logging
- ✅ All requests logged
- ✅ IP tracking
- ✅ User agent tracking
- ✅ Partial key in logs (security)

### 5. Error Handling
- ✅ Clear error messages
- ✅ Appropriate HTTP status codes
- ✅ No sensitive data in errors

## 📋 API Key Configuration Structure

```php
'api_key_string' => [
    'name' => 'Human-readable name',
    'permissions' => ['read', 'write'], // or ['read'] or ['*']
    'rate_limit' => 1000, // requests per hour
    'active' => true // or false to deactivate
]
```

## 🔧 Troubleshooting

### Issue: "API key is required"
**Solution:** Add `X-API-Key` header to request

### Issue: "Invalid API key"
**Solution:** Check key exists in `config.php` and is spelled correctly

### Issue: "API key is inactive"
**Solution:** Set `'active' => true` in `config.php`

### Issue: "Rate limit exceeded"
**Solution:** Wait for next hour or increase `rate_limit` in config

### Issue: "Permission denied"
**Solution:** Check key has required permission (`read` or `write`)

## 📚 Next Steps

1. **Generate Production Keys** - Use `generate-api-key.php`
2. **Update config.php** - Add your keys
3. **Test API** - Use test script or curl
4. **Monitor Usage** - Check logs regularly
5. **Set Up Monitoring** - Track API usage

