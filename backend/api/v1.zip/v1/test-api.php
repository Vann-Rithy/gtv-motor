<?php
/**
 * API v1 Test Script
 * Test the API endpoints locally before deployment
 *
 * Usage: php test-api.php
 */

// Test configuration
$baseUrl = 'http://localhost/backend/api/v1';
$apiKey = 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6'; // Default test key

// Test function
function testEndpoint($url, $apiKey, $description) {
    echo "\n" . str_repeat("=", 60) . "\n";
    echo "Testing: $description\n";
    echo "URL: $url\n";
    echo str_repeat("=", 60) . "\n";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "X-API-Key: $apiKey",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        echo "❌ Error: $error\n";
        return false;
    }

    echo "HTTP Code: $httpCode\n";

    if ($httpCode >= 200 && $httpCode < 300) {
        echo "✅ Success\n";
        $data = json_decode($response, true);
        if ($data) {
            echo "Response:\n";
            echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        } else {
            echo "Response: $response\n";
        }
        return true;
    } else {
        echo "❌ Failed\n";
        echo "Response: $response\n";
        return false;
    }
}

echo "\n";
echo str_repeat("=", 60) . "\n";
echo "GTV Motor API v1 Test Suite\n";
echo str_repeat("=", 60) . "\n";
echo "Base URL: $baseUrl\n";
echo "API Key: " . substr($apiKey, 0, 20) . "...\n";

// Test 1: API Info
testEndpoint("$baseUrl/", $apiKey, "API Information");

// Test 2: Customers List
testEndpoint("$baseUrl/customers?limit=5", $apiKey, "Customers List (5 items)");

// Test 3: Customer by ID (if exists)
testEndpoint("$baseUrl/customers/1", $apiKey, "Customer by ID (1)");

// Test 4: Vehicles List
testEndpoint("$baseUrl/vehicles?limit=5", $apiKey, "Vehicles List (5 items)");

// Test 5: Vehicle by ID (if exists)
testEndpoint("$baseUrl/vehicles/1", $apiKey, "Vehicle by ID (1)");

// Test 6: Invoices List
testEndpoint("$baseUrl/invoices?limit=5", $apiKey, "Invoices List (5 items)");

// Test 7: Invoice by ID (if exists)
testEndpoint("$baseUrl/invoices/1", $apiKey, "Invoice by ID (1)");

// Test 8: Invalid API Key
echo "\n" . str_repeat("=", 60) . "\n";
echo "Testing: Invalid API Key (should fail)\n";
echo str_repeat("=", 60) . "\n";
testEndpoint("$baseUrl/customers", "invalid_key", "Invalid API Key Test");

echo "\n";
echo str_repeat("=", 60) . "\n";
echo "Test Suite Complete\n";
echo str_repeat("=", 60) . "\n";
echo "\n";
echo "Note: Some tests may fail if the database doesn't have the test data.\n";
echo "This is normal. The important thing is that the API structure is working.\n";
echo "\n";

?>

