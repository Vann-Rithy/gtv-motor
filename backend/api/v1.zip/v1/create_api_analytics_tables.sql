-- =====================================================
-- API Traffic Analytics Tables
-- Track and analyze API usage, performance, and traffic
-- =====================================================

-- =====================================================
-- 1. API REQUESTS TABLE
-- Stores detailed information about each API request
-- =====================================================

CREATE TABLE IF NOT EXISTS `api_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_key` varchar(255) DEFAULT NULL COMMENT 'Partial API key (first 10 chars) for security',
  `api_key_id` varchar(100) DEFAULT NULL COMMENT 'API key identifier/name',
  `endpoint` varchar(255) NOT NULL COMMENT 'API endpoint called',
  `method` varchar(10) NOT NULL COMMENT 'HTTP method (GET, POST, PUT, DELETE)',
  `status_code` int(11) NOT NULL COMMENT 'HTTP status code',
  `response_time_ms` int(11) DEFAULT NULL COMMENT 'Response time in milliseconds',
  `request_size_bytes` int(11) DEFAULT NULL COMMENT 'Request size in bytes',
  `response_size_bytes` int(11) DEFAULT NULL COMMENT 'Response size in bytes',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'Client IP address',
  `user_agent` text DEFAULT NULL COMMENT 'User agent string',
  `referer` varchar(500) DEFAULT NULL COMMENT 'HTTP referer',
  `error_message` text DEFAULT NULL COMMENT 'Error message if request failed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_api_key` (`api_key`),
  KEY `idx_endpoint` (`endpoint`),
  KEY `idx_method` (`method`),
  KEY `idx_status_code` (`status_code`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_api_key_created` (`api_key`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='API request logs for analytics';

-- =====================================================
-- 2. API ANALYTICS SUMMARY TABLE
-- Pre-aggregated statistics for faster queries
-- =====================================================

CREATE TABLE IF NOT EXISTS `api_analytics_summary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL COMMENT 'Date of the analytics',
  `api_key_id` varchar(100) DEFAULT NULL COMMENT 'API key identifier',
  `endpoint` varchar(255) DEFAULT NULL COMMENT 'Endpoint (NULL for all endpoints)',
  `total_requests` int(11) NOT NULL DEFAULT 0 COMMENT 'Total number of requests',
  `successful_requests` int(11) NOT NULL DEFAULT 0 COMMENT '2xx status codes',
  `failed_requests` int(11) NOT NULL DEFAULT 0 COMMENT '4xx and 5xx status codes',
  `total_response_time_ms` bigint(20) NOT NULL DEFAULT 0 COMMENT 'Total response time',
  `avg_response_time_ms` decimal(10,2) DEFAULT NULL COMMENT 'Average response time',
  `min_response_time_ms` int(11) DEFAULT NULL COMMENT 'Minimum response time',
  `max_response_time_ms` int(11) DEFAULT NULL COMMENT 'Maximum response time',
  `total_request_size_bytes` bigint(20) DEFAULT 0 COMMENT 'Total request size',
  `total_response_size_bytes` bigint(20) DEFAULT 0 COMMENT 'Total response size',
  `unique_ips` int(11) DEFAULT 0 COMMENT 'Number of unique IP addresses',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_date_key_endpoint` (`date`, `api_key_id`, `endpoint`),
  KEY `idx_date` (`date`),
  KEY `idx_api_key_id` (`api_key_id`),
  KEY `idx_endpoint` (`endpoint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Pre-aggregated API analytics';

-- =====================================================
-- 3. API PERFORMANCE METRICS TABLE
-- Track performance metrics over time
-- =====================================================

CREATE TABLE IF NOT EXISTS `api_performance_metrics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hour` datetime NOT NULL COMMENT 'Hour of the metric',
  `endpoint` varchar(255) DEFAULT NULL COMMENT 'Endpoint (NULL for all)',
  `requests_per_minute` decimal(10,2) DEFAULT NULL COMMENT 'Average requests per minute',
  `avg_response_time_ms` decimal(10,2) DEFAULT NULL COMMENT 'Average response time',
  `p95_response_time_ms` decimal(10,2) DEFAULT NULL COMMENT '95th percentile response time',
  `p99_response_time_ms` decimal(10,2) DEFAULT NULL COMMENT '99th percentile response time',
  `error_rate` decimal(5,2) DEFAULT NULL COMMENT 'Error rate percentage',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_hour_endpoint` (`hour`, `endpoint`),
  KEY `idx_hour` (`hour`),
  KEY `idx_endpoint` (`endpoint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='API performance metrics by hour';

-- =====================================================
-- 4. VIEWS FOR ANALYTICS
-- =====================================================

-- View: API Traffic Overview (Last 24 hours)
CREATE OR REPLACE VIEW `v_api_traffic_overview` AS
SELECT
    DATE(created_at) as date,
    HOUR(created_at) as hour,
    endpoint,
    method,
    COUNT(*) as total_requests,
    SUM(CASE WHEN status_code >= 200 AND status_code < 300 THEN 1 ELSE 0 END) as successful_requests,
    SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as failed_requests,
    AVG(response_time_ms) as avg_response_time_ms,
    MIN(response_time_ms) as min_response_time_ms,
    MAX(response_time_ms) as max_response_time_ms,
    COUNT(DISTINCT ip_address) as unique_ips
FROM api_requests
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
GROUP BY DATE(created_at), HOUR(created_at), endpoint, method
ORDER BY date DESC, hour DESC, total_requests DESC;

-- View: API Usage by Endpoint (Last 7 days)
CREATE OR REPLACE VIEW `v_api_usage_by_endpoint` AS
SELECT
    endpoint,
    method,
    COUNT(*) as total_requests,
    SUM(CASE WHEN status_code >= 200 AND status_code < 300 THEN 1 ELSE 0 END) as successful_requests,
    SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as failed_requests,
    ROUND(AVG(response_time_ms), 2) as avg_response_time_ms,
    ROUND(SUM(response_time_ms) / COUNT(*), 2) as total_avg_response_time,
    COUNT(DISTINCT ip_address) as unique_ips,
    COUNT(DISTINCT api_key) as unique_api_keys
FROM api_requests
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY endpoint, method
ORDER BY total_requests DESC;

-- View: API Usage by API Key (Last 7 days)
CREATE OR REPLACE VIEW `v_api_usage_by_key` AS
SELECT
    api_key_id,
    COUNT(*) as total_requests,
    SUM(CASE WHEN status_code >= 200 AND status_code < 300 THEN 1 ELSE 0 END) as successful_requests,
    SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as failed_requests,
    ROUND(AVG(response_time_ms), 2) as avg_response_time_ms,
    COUNT(DISTINCT endpoint) as endpoints_used,
    COUNT(DISTINCT ip_address) as unique_ips,
    MIN(created_at) as first_request,
    MAX(created_at) as last_request
FROM api_requests
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY api_key_id
ORDER BY total_requests DESC;

-- View: API Error Analysis (Last 7 days)
CREATE OR REPLACE VIEW `v_api_errors` AS
SELECT
    status_code,
    endpoint,
    method,
    error_message,
    COUNT(*) as error_count,
    COUNT(DISTINCT ip_address) as affected_ips,
    MAX(created_at) as last_occurrence
FROM api_requests
WHERE status_code >= 400
AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY status_code, endpoint, method, error_message
ORDER BY error_count DESC;

-- View: API Performance Trends (Hourly)
-- Note: Percentiles calculated using MySQL-compatible method
CREATE OR REPLACE VIEW `v_api_performance_trends` AS
SELECT
    DATE_FORMAT(created_at, '%Y-%m-%d %H:00:00') as hour,
    endpoint,
    COUNT(*) as requests,
    ROUND(AVG(response_time_ms), 2) as avg_response_time_ms,
    ROUND(MIN(response_time_ms), 2) as min_response_time_ms,
    ROUND(MAX(response_time_ms), 2) as max_response_time_ms,
    ROUND(SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as error_rate_percent
FROM api_requests
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY DATE_FORMAT(created_at, '%Y-%m-%d %H:00:00'), endpoint
ORDER BY hour DESC;

-- =====================================================
-- 5. STORED PROCEDURES FOR ANALYTICS
-- =====================================================

-- Procedure: Get API Statistics for Date Range
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `sp_get_api_statistics`(
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_endpoint VARCHAR(255)
)
BEGIN
    SELECT
        DATE(created_at) as date,
        COUNT(*) as total_requests,
        SUM(CASE WHEN status_code >= 200 AND status_code < 300 THEN 1 ELSE 0 END) as successful_requests,
        SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as failed_requests,
        ROUND(AVG(response_time_ms), 2) as avg_response_time_ms,
        MIN(response_time_ms) as min_response_time_ms,
        MAX(response_time_ms) as max_response_time_ms,
        COUNT(DISTINCT ip_address) as unique_ips,
        COUNT(DISTINCT api_key) as unique_api_keys,
        ROUND(SUM(request_size_bytes) / 1024 / 1024, 2) as total_request_size_mb,
        ROUND(SUM(response_size_bytes) / 1024 / 1024, 2) as total_response_size_mb
    FROM api_requests
    WHERE DATE(created_at) BETWEEN p_start_date AND p_end_date
    AND (p_endpoint IS NULL OR endpoint = p_endpoint)
    GROUP BY DATE(created_at)
    ORDER BY date DESC;
END //
DELIMITER ;

-- Procedure: Get Top Endpoints
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `sp_get_top_endpoints`(
    IN p_days INT,
    IN p_limit INT
)
BEGIN
    SELECT
        endpoint,
        method,
        COUNT(*) as total_requests,
        ROUND(AVG(response_time_ms), 2) as avg_response_time_ms,
        SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as failed_requests,
        ROUND(SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as error_rate_percent
    FROM api_requests
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL p_days DAY)
    GROUP BY endpoint, method
    ORDER BY total_requests DESC
    LIMIT p_limit;
END //
DELIMITER ;

-- =====================================================
-- VERIFICATION
-- =====================================================

-- Check tables created
SELECT
    'Tables Created' as info,
    COUNT(*) as count
FROM information_schema.tables
WHERE table_schema = DATABASE()
AND table_name IN ('api_requests', 'api_analytics_summary', 'api_performance_metrics');

-- Check views created
SELECT
    'Views Created' as info,
    COUNT(*) as count
FROM information_schema.views
WHERE table_schema = DATABASE()
AND table_name LIKE 'v_api_%';

-- Check procedures created
SELECT
    'Procedures Created' as info,
    COUNT(*) as count
FROM information_schema.routines
WHERE routine_schema = DATABASE()
AND routine_name LIKE 'sp_get_api%';

SELECT 'API Analytics tables, views, and procedures created successfully!' as status;

