# API Key Setup and Usage Guide

## 🔑 API Key Overview

The GTV Motor API v1 uses **API Key Authentication** to secure access to your data. Every request must include a valid API key.

## 📋 How API Key Authentication Works

### Authentication Flow

```
1. Client sends request with API key
   ↓
2. API validates API key exists
   ↓
3. API checks if key is active
   ↓
4. API checks rate limit
   ↓
5. API checks permissions
   ↓
6. Request is processed
```

## 🔐 Step 1: Generate API Keys

### Method 1: Using PHP (Recommended)

Create a file `generate-api-key.php`:

```php
<?php
// Generate a secure API key
$secret = 'gtvmotor_production_secret_2024'; // Change this!
$apiKey = hash('sha256', $secret . date('Y'));

echo "Your API Key: " . $apiKey . "\n";
echo "Length: " . strlen($apiKey) . " characters\n";
?>
```

Run it:
```bash
php generate-api-key.php
```

### Method 2: Using Command Line

**Windows (PowerShell):**
```powershell
$secret = "gtvmotor_production_secret_2024"
$input = $secret + (Get-Date).Year
$bytes = [System.Text.Encoding]::UTF8.GetBytes($input)
$hash = [System.Security.Cryptography.SHA256]::Create().ComputeHash($bytes)
$apiKey = [System.BitConverter]::ToString($hash).Replace("-", "").ToLower()
Write-Host $apiKey
```

**Linux/Mac:**
```bash
echo -n "gtvmotor_production_secret_2024$(date +%Y)" | sha256sum
```

### Method 3: Online Tool
Visit: https://emn178.github.io/online-tools/sha256.html
- Enter: `gtvmotor_production_secret_2024`
- Copy the generated hash

## ⚙️ Step 2: Configure API Keys

### Edit `backend/api/v1/config.php`

```php
define('API_V1_KEYS', [
    // Production API Key (Full Access)
    'your_generated_api_key_here' => [
        'name' => 'Production API Key',
        'permissions' => ['read', 'write'], // Can read and write
        'rate_limit' => 1000, // 1000 requests per hour
        'active' => true
    ],

    // Read-Only API Key (For Reporting)
    'another_generated_key_here' => [
        'name' => 'Read-Only API Key',
        'permissions' => ['read'], // Can only read
        'rate_limit' => 500, // 500 requests per hour
        'active' => true
    ],

    // Client-Specific API Key
    'client_specific_key_here' => [
        'name' => 'Client ABC API Key',
        'permissions' => ['read'], // Read-only for client
        'rate_limit' => 100, // Limited to 100 requests/hour
        'active' => true
    ],
]);
```

### Permission Types

- `'read'` - Can only GET data (read-only)
- `'write'` - Can POST/PUT/DELETE data (read + write)
- `'*'` - Full access (all permissions)

## 📡 Step 3: Using API Keys in Requests

### Method 1: X-API-Key Header (Recommended)

**cURL:**
```bash
curl -X GET "https://api.gtvmotor.dev/v1/customers" \
  -H "X-API-Key: your_api_key_here"
```

**JavaScript (Fetch):**
```javascript
fetch('https://api.gtvmotor.dev/v1/customers', {
  headers: {
    'X-API-Key': 'your_api_key_here',
    'Content-Type': 'application/json'
  }
})
.then(response => response.json())
.then(data => console.log(data));
```

**PHP:**
```php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.gtvmotor.dev/v1/customers');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-Key: your_api_key_here',
    'Content-Type: application/json'
]);
$response = curl_exec($ch);
curl_close($ch);
```

**Python:**
```python
import requests

headers = {
    'X-API-Key': 'your_api_key_here',
    'Content-Type': 'application/json'
}

response = requests.get('https://api.gtvmotor.dev/v1/customers', headers=headers)
print(response.json())
```

### Method 2: Authorization Header

**Bearer Token Format:**
```bash
curl -X GET "https://api.gtvmotor.dev/v1/customers" \
  -H "Authorization: Bearer your_api_key_here"
```

**ApiKey Format:**
```bash
curl -X GET "https://api.gtvmotor.dev/v1/customers" \
  -H "Authorization: ApiKey your_api_key_here"
```

### Method 3: Query Parameter (Less Secure - Not Recommended)

```bash
curl "https://api.gtvmotor.dev/v1/customers?api_key=your_api_key_here"
```

⚠️ **Warning:** Query parameters may be logged in server logs. Use headers instead.

## 🔄 API Request Process

### Complete Request Flow

```
┌─────────────────┐
│  Client Request │
│  + API Key      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  API Middleware │
│  - Extract Key  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Validate Key   │
│  - Exists?      │
│  - Active?      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Check Rate Limit│
│  - Within limit?│
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Check Permission│
│  - Has access?  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Process Request│
│  - Execute      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Log Request    │
│  - Save log     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Return Response│
└─────────────────┘
```

## 📝 Example API Requests

### 1. Get All Customers

```bash
curl -X GET "https://api.gtvmotor.dev/v1/customers?page=1&limit=10" \
  -H "X-API-Key: your_api_key_here"
```

**Response:**
```json
{
  "success": true,
  "message": "Customers retrieved successfully",
  "data": [
    {
      "id": 1,
      "name": "Poeng Lim",
      "phone": "883176894",
      "email": "poenglim@email.com",
      "address": "Phnom Penh",
      "vehicle_count": 1,
      "service_count": 2,
      "total_spent": 450.00
    }
  ],
  "pagination": {
    "total": 100,
    "page": 1,
    "limit": 10,
    "totalPages": 10
  }
}
```

### 2. Get Customer by ID (Full Information)

```bash
curl -X GET "https://api.gtvmotor.dev/v1/customers/1" \
  -H "X-API-Key: your_api_key_here"
```

**Response includes:**
- Customer details
- All vehicles
- All services with items
- Statistics

### 3. Get Vehicle by Plate Number

```bash
curl -X GET "https://api.gtvmotor.dev/v1/vehicles?plate_number=2CD-7960" \
  -H "X-API-Key: your_api_key_here"
```

### 4. Get Service Invoice

```bash
curl -X GET "https://api.gtvmotor.dev/v1/invoices/1" \
  -H "X-API-Key: your_api_key_here"
```

**Response includes:**
- Complete service information
- Customer details
- Vehicle details
- Service items
- Invoice totals (subtotal, VAT, total, KHR)

## 🚦 Rate Limiting

### How It Works

- Each API key has a rate limit (requests per hour)
- Default: 1000 requests/hour
- Rate limit resets every hour
- Exceeding limit returns: `429 Too Many Requests`

### Check Your Rate Limit

Rate limit data is stored in:
```
backend/logs/rate_limit_[key_hash].json
```

### Example Rate Limit Response

```json
{
  "success": false,
  "error": "Rate limit exceeded. Maximum 1000 requests per hour.",
  "timestamp": "2024-10-01T12:00:00+00:00"
}
```

## 🔒 Security Best Practices

### 1. Generate Strong Keys

✅ **Good:**
```php
hash('sha256', 'gtvmotor_production_' . uniqid() . time());
```

❌ **Bad:**
```php
'my_api_key_123' // Too simple, predictable
```

### 2. Store Keys Securely

✅ **Good:**
- Environment variables
- Secure key management service
- Encrypted configuration files

❌ **Bad:**
- Hardcoded in code
- Committed to Git
- Shared in plain text

### 3. Use Different Keys for Different Purposes

- **Production Key**: Full access, high rate limit
- **Read-Only Key**: For reporting/dashboards
- **Client Keys**: Limited access per client
- **Test Key**: For development/testing

### 4. Rotate Keys Periodically

- Change keys every 3-6 months
- Notify clients before rotation
- Keep old keys active during transition

## 🛠️ API Key Management

### Adding a New API Key

1. Generate key using methods above
2. Add to `config.php`:
```php
'new_generated_key' => [
    'name' => 'New Client API Key',
    'permissions' => ['read'],
    'rate_limit' => 200,
    'active' => true
],
```

### Deactivating an API Key

Set `'active' => false`:
```php
'old_key' => [
    'name' => 'Old Key',
    'permissions' => ['read', 'write'],
    'rate_limit' => 1000,
    'active' => false  // ← Deactivated
],
```

### Changing Rate Limits

Update the `rate_limit` value:
```php
'api_key' => [
    'name' => 'API Key',
    'permissions' => ['read', 'write'],
    'rate_limit' => 2000, // ← Increased from 1000
    'active' => true
],
```

## 📊 Monitoring API Usage

### View API Logs

```bash
# View recent API requests
tail -f backend/logs/api_v1.log

# Search for specific API key usage
grep "api_key_prefix" backend/logs/api_v1.log
```

### Check Rate Limit Status

```bash
# View rate limit file
cat backend/logs/rate_limit_[key_hash].json
```

**Example output:**
```json
{
  "hour": "2024-10-01-14",
  "count": 245
}
```

## ❌ Error Responses

### Missing API Key

```json
{
  "success": false,
  "error": "API key is required. Please provide X-API-Key header.",
  "timestamp": "2024-10-01T12:00:00+00:00"
}
```

### Invalid API Key

```json
{
  "success": false,
  "error": "Invalid API key.",
  "timestamp": "2024-10-01T12:00:00+00:00"
}
```

### Inactive API Key

```json
{
  "success": false,
  "error": "API key is inactive.",
  "timestamp": "2024-10-01T12:00:00+00:00"
}
```

### Rate Limit Exceeded

```json
{
  "success": false,
  "error": "Rate limit exceeded. Maximum 1000 requests per hour.",
  "timestamp": "2024-10-01T12:00:00+00:00"
}
```

### Permission Denied

```json
{
  "success": false,
  "error": "API key does not have read permission.",
  "timestamp": "2024-10-01T12:00:00+00:00"
}
```

## 🧪 Testing Your API Key

### Quick Test Script

Create `test-api-key.php`:

```php
<?php
$apiKey = 'your_api_key_here';
$baseUrl = 'https://api.gtvmotor.dev/v1';

// Test 1: API Info
$ch = curl_init($baseUrl . '/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['X-API-Key: ' . $apiKey]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Test 1 - API Info:\n";
echo "HTTP Code: $httpCode\n";
echo "Response: $response\n\n";

// Test 2: Get Customers
$ch = curl_init($baseUrl . '/customers?limit=5');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['X-API-Key: ' . $apiKey]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Test 2 - Get Customers:\n";
echo "HTTP Code: $httpCode\n";
echo "Response: " . substr($response, 0, 200) . "...\n";
?>
```

## 📋 Quick Reference

### Default Test API Key
```
a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6
```

⚠️ **Change this in production!**

### API Endpoints

- `GET /v1/` - API information
- `GET /v1/customers` - List customers
- `GET /v1/customers/{id}` - Get customer details
- `GET /v1/vehicles` - List vehicles
- `GET /v1/vehicles/{id}` - Get vehicle details
- `GET /v1/invoices` - List invoices
- `GET /v1/invoices/{id}` - Get invoice details

### Required Headers

```
X-API-Key: your_api_key_here
Content-Type: application/json
```

## 🔐 Production Checklist

- [ ] Generate secure API keys (not default test key)
- [ ] Store keys securely (not in Git)
- [ ] Set appropriate rate limits
- [ ] Configure permissions correctly
- [ ] Enable HTTPS requirement
- [ ] Set up logging
- [ ] Test all endpoints
- [ ] Document keys for team
- [ ] Set up key rotation schedule

## 📞 Support

For API key issues:
- Check logs: `backend/logs/api_v1.log`
- Verify key in `config.php`
- Test with curl/Postman
- Contact: api@gtvmotor.dev

