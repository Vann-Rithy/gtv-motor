-- =====================================================
-- Add API Settings to Database
-- Store API configuration in system_config table
-- =====================================================

-- Add API settings to system_config table
-- These are frontend/client-side API configuration settings

INSERT INTO `system_config` (`config_key`, `config_value`, `config_type`, `description`, `created_at`, `updated_at`)
VALUES
('api_base_url', 'https://api.gtvmotor.dev/api/v1', 'string', 'API Base URL for all API requests', NOW(), NOW()),
('api_key', '', 'string', 'API key for authentication (stored encrypted)', NOW(), NOW()),
('api_timeout', '30000', 'number', 'Request timeout in milliseconds', NOW(), NOW()),
('api_retry_attempts', '3', 'number', 'Number of retry attempts for failed requests', NOW(), NOW()),
('api_cache_duration', '300', 'number', 'Cache duration in seconds', NOW(), NOW()),
('api_enable_caching', 'true', 'boolean', 'Enable API response caching', NOW(), NOW())
ON DUPLICATE KEY UPDATE
    `config_value` = VALUES(`config_value`),
    `updated_at` = NOW();

-- Verify the settings were added
SELECT
    config_key,
    config_value,
    config_type,
    description
FROM system_config
WHERE config_key LIKE 'api_%'
ORDER BY config_key;

