<?php
/**
 * API v1 Debug Script
 * Use this to check what's causing the 500 error
 */

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

echo "<h1>API v1 Debug</h1>";

echo "<h2>1. PHP Version</h2>";
echo "PHP Version: " . phpversion() . "<br>";

echo "<h2>2. Current Directory</h2>";
echo "__DIR__: " . __DIR__ . "<br>";
echo "Current working directory: " . getcwd() . "<br>";

echo "<h2>3. File Existence Check</h2>";
$files = [
    'config.php' => __DIR__ . '/config.php',
    '../config/config.php' => __DIR__ . '/../config/config.php',
    '../includes/Response.php' => __DIR__ . '/../includes/Response.php',
];

foreach ($files as $name => $path) {
    $exists = file_exists($path);
    echo "$name: " . ($exists ? "✅ EXISTS" : "❌ NOT FOUND") . " ($path)<br>";
}

echo "<h2>4. Try Loading Files</h2>";
try {
    if (file_exists(__DIR__ . '/../config/config.php')) {
        require_once __DIR__ . '/../config/config.php';
        echo "✅ config.php loaded<br>";
    } else {
        echo "❌ config.php not found<br>";
    }
} catch (Exception $e) {
    echo "❌ Error loading config.php: " . $e->getMessage() . "<br>";
}

try {
    if (file_exists(__DIR__ . '/../includes/Response.php')) {
        require_once __DIR__ . '/../includes/Response.php';
        echo "✅ Response.php loaded<br>";
    } else {
        echo "❌ Response.php not found<br>";
    }
} catch (Exception $e) {
    echo "❌ Error loading Response.php: " . $e->getMessage() . "<br>";
}

try {
    if (file_exists(__DIR__ . '/config.php')) {
        require_once __DIR__ . '/config.php';
        echo "✅ v1/config.php loaded<br>";

        if (defined('API_V1_VERSION')) {
            echo "✅ API_V1_VERSION: " . API_V1_VERSION . "<br>";
        } else {
            echo "❌ API_V1_VERSION not defined<br>";
        }
    } else {
        echo "❌ v1/config.php not found<br>";
    }
} catch (Exception $e) {
    echo "❌ Error loading v1/config.php: " . $e->getMessage() . "<br>";
}

echo "<h2>5. Server Info</h2>";
echo "REQUEST_URI: " . ($_SERVER['REQUEST_URI'] ?? 'N/A') . "<br>";
echo "SCRIPT_NAME: " . ($_SERVER['SCRIPT_NAME'] ?? 'N/A') . "<br>";
echo "DOCUMENT_ROOT: " . ($_SERVER['DOCUMENT_ROOT'] ?? 'N/A') . "<br>";

echo "<h2>6. Test Response Class</h2>";
if (class_exists('Response')) {
    echo "✅ Response class exists<br>";
    try {
        Response::success(['test' => 'data'], 'Test message');
        echo "✅ Response::success() works<br>";
    } catch (Exception $e) {
        echo "❌ Response::success() error: " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ Response class not found<br>";
}

?>

