# API Key Storage Guide - Where to Store API Keys

## 🔐 **Two Types of API Keys**

### 1. **Backend API Keys** (Server-side)
- **Purpose:** Validate incoming API requests
- **Location:** `backend/api/v1/config.php`
- **Who uses:** Backend server (validates requests)

### 2. **Frontend API Key** (Client-side)
- **Purpose:** Key entered by user to make API requests
- **Location:** Database (`system_config` table) OR Frontend only
- **Who uses:** Frontend application (sends with requests)

---

## 📍 **Where to Store Each Type**

### **1. Backend API Keys** (Server-side)

#### ✅ **Current Location: `backend/api/v1/config.php`**

```php
define('API_V1_KEYS', [
    'your_api_key_here' => [
        'name' => 'Production API Key',
        'permissions' => ['read', 'write'],
        'rate_limit' => 1000,
        'active' => true
    ],
]);
```

#### ⚠️ **Security Recommendations:**

**Option 1: Keep in `config.php` (Current - OK for now)**
- ✅ Simple and works
- ⚠️ Keys visible in code (if Git is compromised)
- ✅ Good for development/testing

**Option 2: Environment Variables (Recommended for Production)**
```php
// .env file (NOT in Git)
API_V1_KEY_1=your_secret_key_here
API_V1_KEY_1_NAME=Production Key
API_V1_KEY_1_PERMISSIONS=read,write
API_V1_KEY_1_RATE_LIMIT=1000

// config.php
define('API_V1_KEYS', [
    getenv('API_V1_KEY_1') => [
        'name' => getenv('API_V1_KEY_1_NAME'),
        'permissions' => explode(',', getenv('API_V1_KEY_1_PERMISSIONS')),
        'rate_limit' => (int)getenv('API_V1_KEY_1_RATE_LIMIT'),
        'active' => true
    ],
]);
```

**Option 3: Database Table (Most Secure)**
```sql
CREATE TABLE `api_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_hash` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `permissions` json NOT NULL,
  `rate_limit` int(11) DEFAULT 1000,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_hash` (`key_hash`)
);
```

**Store hashed keys:**
```php
// Store hash, not actual key
$keyHash = hash('sha256', $apiKey);
// Compare: hash('sha256', $providedKey) === $storedHash
```

---

### **2. Frontend API Key** (User-entered)

#### ✅ **Current: Database (`system_config` table)**

**Location:** `system_config.config_key = 'api_key'`

**Pros:**
- ✅ Persists across sessions
- ✅ Available on all devices
- ✅ Can be backed up

**Cons:**
- ⚠️ Stored in plain text (if not encrypted)
- ⚠️ Visible in database

#### 🔐 **Security Options:**

**Option 1: Store in Database (Current - OK)**
```sql
-- In system_config table
INSERT INTO system_config (config_key, config_value, config_type)
VALUES ('api_key', 'user_entered_key', 'string');
```

**Option 2: Encrypt in Database (Recommended)**
```php
// When saving
$encrypted = openssl_encrypt($apiKey, 'AES-256-CBC', $encryptionKey);
// Store encrypted value

// When loading
$apiKey = openssl_decrypt($encrypted, 'AES-256-CBC', $encryptionKey);
```

**Option 3: Browser localStorage (Less Secure)**
```javascript
// Store in browser only
localStorage.setItem('api_key', apiKey);
// Not synced across devices
```

**Option 4: Session Storage (Most Secure for Frontend)**
```javascript
// Store in session only (cleared on browser close)
sessionStorage.setItem('api_key', apiKey);
// Not persisted
```

---

## 🎯 **Recommended Setup**

### **For Production:**

#### **Backend API Keys:**
1. ✅ **Use Environment Variables** (`.env` file)
2. ✅ **Never commit `.env` to Git**
3. ✅ **Use different keys per environment** (dev/staging/prod)

#### **Frontend API Key:**
1. ✅ **Store in Database** (for persistence)
2. ✅ **Encrypt before storing** (optional but recommended)
3. ✅ **Allow user to enter/change** (in settings form)

---

## 📋 **Current Setup Summary**

### **Backend API Keys:**
- **Location:** `backend/api/v1/config.php`
- **Status:** ✅ Works, but should move to `.env` for production
- **Security:** ⚠️ Visible in code (OK for dev, not ideal for prod)

### **Frontend API Key:**
- **Location:** `system_config` table (`api_key` config)
- **Status:** ✅ Stored in database
- **Security:** ⚠️ Plain text (can encrypt if needed)

---

## 🔧 **Quick Security Improvements**

### **1. Move Backend Keys to Environment Variables**

Create `.env` file:
```env
API_V1_KEY_1=your_production_key_here
API_V1_KEY_1_NAME=Production API Key
API_V1_KEY_1_PERMISSIONS=read,write
API_V1_KEY_1_RATE_LIMIT=1000
```

Update `config.php`:
```php
define('API_V1_KEYS', [
    getenv('API_V1_KEY_1') ?: 'fallback_key' => [
        'name' => getenv('API_V1_KEY_1_NAME') ?: 'Default Key',
        'permissions' => explode(',', getenv('API_V1_KEY_1_PERMISSIONS') ?: 'read'),
        'rate_limit' => (int)(getenv('API_V1_KEY_1_RATE_LIMIT') ?: 1000),
        'active' => true
    ],
]);
```

### **2. Encrypt Frontend API Key (Optional)**

Update `backend/api/settings.php`:
```php
// When saving
$encryptionKey = getenv('ENCRYPTION_KEY') ?: 'your-secret-key';
$encrypted = openssl_encrypt($data['apiKey'], 'AES-256-CBC', $encryptionKey);
// Store $encrypted instead of $data['apiKey']

// When loading
$decrypted = openssl_decrypt($encrypted, 'AES-256-CBC', $encryptionKey);
// Return $decrypted to frontend
```

---

## ✅ **Best Practices**

### **Backend API Keys:**
1. ✅ Store in environment variables (`.env`)
2. ✅ Never commit to Git (add `.env` to `.gitignore`)
3. ✅ Use different keys per environment
4. ✅ Rotate keys periodically
5. ✅ Use strong, random keys

### **Frontend API Key:**
1. ✅ Store in database (for persistence)
2. ✅ Encrypt if sensitive
3. ✅ Allow user to change/update
4. ✅ Clear on logout (optional)
5. ✅ Validate format before saving

---

## 📊 **Storage Comparison**

| Location | Security | Persistence | Multi-device | Best For |
|----------|----------|-------------|--------------|----------|
| **Backend: config.php** | ⚠️ Medium | ✅ Yes | ✅ Yes | Development |
| **Backend: .env** | ✅ High | ✅ Yes | ✅ Yes | Production |
| **Backend: Database** | ✅ High | ✅ Yes | ✅ Yes | Production |
| **Frontend: Database** | ⚠️ Medium | ✅ Yes | ✅ Yes | Current setup |
| **Frontend: localStorage** | ⚠️ Low | ✅ Yes | ❌ No | Simple apps |
| **Frontend: sessionStorage** | ✅ High | ❌ No | ❌ No | High security |

---

## 🎯 **Recommendation for Your Setup**

### **Current (Works Fine):**
- ✅ Backend keys in `config.php` (OK for now)
- ✅ Frontend key in database (Good for persistence)

### **For Production:**
- 🔄 Move backend keys to `.env` file
- 🔄 Encrypt frontend key in database (optional)
- 🔄 Add `.env` to `.gitignore`

---

## 📝 **Summary**

**Backend API Keys:**
- **Current:** `backend/api/v1/config.php`
- **Recommended:** Environment variables (`.env`)

**Frontend API Key:**
- **Current:** Database (`system_config.api_key`)
- **Status:** ✅ Good (can encrypt if needed)

Both locations are functional. For production, consider moving backend keys to environment variables for better security.

