# Database Requirements for API v1

## Overview

This document lists all database table requirements for the GTV Motor API v1 to function correctly.

## Required Tables and Columns

### 1. `services` Table

**Required Columns:**
- `id` (int, primary key, auto_increment)
- `invoice_number` (varchar(20), unique)
- `customer_id` (int, foreign key to customers.id)
- `vehicle_id` (int, foreign key to vehicles.id)
- `vehicle_model_id` (int, foreign key to vehicle_models.id, nullable)
- `service_type_id` (int, foreign key to service_types.id)
- `service_date` (date)
- `current_km` (int, nullable)
- `next_service_km` (int, nullable)
- `next_service_date` (date, nullable)
- `total_amount` (decimal(10,2))
- `payment_method` (enum: 'cash','aba','card','bank_transfer')
- `payment_status` (enum: 'pending','paid','cancelled')
- `service_status` (enum: 'pending','in_progress','completed','cancelled')
- `notes` (text, nullable)
- `service_detail` (text, nullable)
- `technician_id` (int, foreign key to staff.id, nullable)
- `sales_rep_id` (int, foreign key to staff.id, nullable)
- `customer_type` (enum: 'booking','walking', default: 'walking')
- `booking_id` (int, nullable)
- `service_cost` (decimal(10,2), default: 100.00)
- `created_at` (timestamp)
- `updated_at` (timestamp)

**API-Specific Columns (may need to be added):**
- `exchange_rate` (decimal(8,2), nullable) - Exchange rate USD to KHR
- `total_khr` (decimal(12,2), nullable) - Total amount in KHR
- `volume_l` (decimal(5,2), nullable) - Engine volume in liters

**Indexes:**
- PRIMARY KEY on `id`
- UNIQUE KEY on `invoice_number`
- INDEX on `exchange_rate`
- INDEX on `total_khr`

### 2. `service_items` Table

**Required Columns:**
- `id` (int, primary key, auto_increment)
- `service_id` (int, foreign key to services.id)
- `description` (text)
- `quantity` (int, default: 1)
- `unit_price` (decimal(10,2))
- `total_price` (decimal(10,2))
- `item_type` (enum: 'service','part','labor', default: 'service')
- `created_at` (timestamp)

**API-Specific Columns (may need to be added):**
- `inventory_item_id` (int, nullable) - Reference to inventory_items table
- `updated_at` (timestamp, nullable)

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `service_id`

### 3. `customers` Table

**Required Columns:**
- `id` (int, primary key, auto_increment)
- `name` (varchar(255))
- `phone` (varchar(20))
- `email` (varchar(255), nullable)
- `address` (text, nullable)
- `created_at` (timestamp)
- `updated_at` (timestamp)

**Note:** Remove duplicate columns if they exist:
- `customer_name` (duplicate of `name`)
- `customer_email` (duplicate of `email`)
- `customer_address` (duplicate of `address`)

### 4. `vehicles` Table

**Required Columns:**
- `id` (int, primary key, auto_increment)
- `customer_id` (int, foreign key to customers.id)
- `plate_number` (varchar(20), unique)
- `vehicle_model_id` (int, foreign key to vehicle_models.id, nullable)
- `vin_number` (varchar(50), nullable)
- `year` (int, nullable)
- `current_km` (int, default: 50000)
- `purchase_date` (date, nullable)
- `warranty_start_date` (date, nullable)
- `warranty_end_date` (date, nullable)
- `warranty_km_limit` (int, default: 15000)
- `warranty_service_count` (int, default: 0)
- `warranty_max_services` (int, default: 2)
- `created_at` (timestamp)
- `updated_at` (timestamp)

**Note:** Remove duplicate column if it exists:
- `vehicle_plate` (duplicate of `plate_number`)

### 5. `vehicle_models` Table

**Required Columns:**
- `id` (int, primary key, auto_increment)
- `name` (varchar(100), unique)
- `description` (text, nullable)
- `category` (varchar(50), default: 'Motorcycle')
- `base_price` (decimal(10,2), default: 0.00)
- `estimated_duration` (int, default: 60)
- `warranty_km_limit` (int, default: 15000)
- `warranty_max_services` (int, default: 2)
- `engine_type` (varchar(50), default: '4-Stroke')
- `cc_displacement` (int, nullable)
- `fuel_type` (varchar(20), default: 'Gasoline')
- `transmission` (varchar(20), default: 'Manual')
- `color_options` (json, nullable)
- `year_range` (varchar(20), nullable)
- `specifications` (json, nullable)
- `is_active` (tinyint(1), default: 1)
- `created_at` (timestamp)
- `updated_at` (timestamp)

### 6. `service_types` Table

**Required Columns:**
- `id` (int, primary key, auto_increment)
- `service_type_name` (varchar(255))
- `category` (varchar(50), nullable)
- `description` (text, nullable)
- `created_at` (timestamp)

### 7. `staff` Table

**Required Columns:**
- `id` (int, primary key, auto_increment)
- `name` (varchar(255))
- `role` (varchar(50), nullable)
- Other staff-related columns

### 8. `warranties` Table (Optional - for warranty information)

**Required Columns:**
- `id` (int, primary key, auto_increment)
- `vehicle_id` (int, foreign key to vehicles.id)
- `warranty_type` (varchar(50), nullable)
- `start_date` (date, nullable)
- `end_date` (date, nullable)
- `km_limit` (int, nullable)
- `service_count` (int, nullable)
- `max_services` (int, nullable)
- `cost_covered` (decimal(10,2), nullable)

## Database Update Script

Run the following script to add missing columns:

```bash
mysql -u your_username -p your_database < backend/api/v1/update_database_for_api.sql
```

Or execute it in phpMyAdmin or your MySQL client.

## Verification

After running the update script, verify the changes:

```sql
-- Check services table
DESCRIBE services;

-- Check service_items table
DESCRIBE service_items;

-- Check if new columns exist
SELECT COLUMN_NAME
FROM information_schema.columns
WHERE table_schema = DATABASE()
AND table_name = 'services'
AND column_name IN ('exchange_rate', 'total_khr', 'volume_l');
```

## Migration Notes

1. **Backup First**: Always backup your database before running migration scripts
2. **Test Environment**: Test the migration on a development database first
3. **Downtime**: The migration should be quick, but plan for minimal downtime
4. **Data Integrity**: Existing data will be preserved, new columns will be NULL initially

## Troubleshooting

### Column Already Exists Error
If you get "Column already exists" errors, it means the column was already added. This is safe to ignore.

### Foreign Key Constraints
If you have foreign key constraints, ensure referenced tables exist before adding foreign keys.

### Index Creation
If index creation fails, it may already exist. Check existing indexes first.

## Support

For database-related issues:
- Check the update script: `backend/api/v1/update_database_for_api.sql`
- Review error logs
- Contact database administrator

