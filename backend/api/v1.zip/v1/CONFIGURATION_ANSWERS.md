# API Configuration Answers

## ❓ Question 1: "on table no need to update?"

### Answer: ⚠️ **YES, Database Update is Needed** (But Minimal)

**Status:** You need to add **2 columns** to the `service_items` table.

**What's Missing:**
1. `inventory_item_id` - For linking service items to inventory
2. `updated_at` - For tracking when items are updated

**What's Already Good:**
- ✅ `services` table - Complete (has exchange_rate, total_khr, volume_l)
- ✅ `customers` table - Clean (no duplicate columns)
- ✅ `vehicles` table - Clean (no duplicate columns)

**Action Required:**
```bash
# Run this SQL script
mysql -u your_username -p your_database < backend/api/v1/update_database_minimal.sql
```

**Impact:** Without these columns, the API will work but may have issues with inventory tracking and update timestamps.

---

## ❓ Question 2: "all this it correct?" (API Configuration Settings)

### Answer: ⚠️ **Almost Correct - One Fix Needed**

### Your Settings Review:

| Setting | Your Value | Status | Recommendation |
|---------|------------|--------|----------------|
| **API Base URL** | `https://api.gtvmotor.dev` | ⚠️ **Needs Fix** | Add `/v1/` → `https://api.gtvmotor.dev/v1` |
| **API Key** | (User enters) | ✅ **Correct** | Must match key in `backend/api/v1/config.php` |
| **Request Timeout** | `30000ms` (30s) | ✅ **Perfect** | Good timeout value |
| **Retry Attempts** | `3` | ✅ **Correct** | Matches best practices |
| **Cache Duration** | `300s` (5 min) | ✅ **Good** | Good for performance |
| **Enable API Caching** | `Enabled` | ✅ **Good** | Improves performance |

### ⚠️ **Issue Found:**

**API Base URL is Missing `/v1/`**

**Current:** `https://api.gtvmotor.dev`
**Should be:** `https://api.gtvmotor.dev/v1`

**Why?** The API v1 endpoints are located at `/v1/`, not at the root.

**Example:**
- ❌ Wrong: `https://api.gtvmotor.dev/customers` → 404 Not Found
- ✅ Correct: `https://api.gtvmotor.dev/v1/customers` → Works!

---

## ✅ Corrected Configuration

### Update Your Settings To:

```
API Base URL: https://api.gtvmotor.dev/v1
API Key: [Your generated API key from backend/api/v1/config.php]
Request Timeout: 30000
Retry Attempts: 3
Cache Duration: 300
Enable API Caching: ✓ (checked)
```

---

## 📋 Complete Setup Checklist

### Step 1: Update Database
```bash
mysql -u username -p database_name < backend/api/v1/update_database_minimal.sql
```

### Step 2: Generate API Key
```bash
php backend/api/v1/generate-api-key.php
```

### Step 3: Add API Key to Backend
Edit `backend/api/v1/config.php`:
```php
'your_generated_key_here' => [
    'name' => 'Frontend API Key',
    'permissions' => ['read', 'write'],
    'rate_limit' => 1000,
    'active' => true
],
```

### Step 4: Update Frontend Settings
- Go to Settings → API Configuration
- Set Base URL: `https://api.gtvmotor.dev/v1` ← **Add /v1**
- Enter API Key
- Set Timeout: `30000`
- Set Retry: `3`
- Set Cache: `300`
- Enable Caching: ✓
- Click "Save API Settings"

---

## 🧪 Test Your Configuration

### Test 1: Database Update
```sql
-- Check if columns exist
SELECT COLUMN_NAME
FROM information_schema.columns
WHERE table_name = 'service_items'
AND column_name IN ('inventory_item_id', 'updated_at');
```

**Expected:** Should return 2 rows

### Test 2: API Connection
```bash
curl -X GET "https://api.gtvmotor.dev/v1/customers" \
  -H "X-API-Key: your_api_key_here"
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Customers retrieved successfully",
  "data": [...]
}
```

### Test 3: Frontend Settings
1. Open browser console (F12)
2. Navigate to Settings → API Configuration
3. Verify Base URL shows: `https://api.gtvmotor.dev/v1`
4. Verify API Key is entered
5. Save settings
6. Try loading customers page

---

## 📊 Summary

### Database: ⚠️ **Update Required**
- **Action:** Run `update_database_minimal.sql`
- **Impact:** Adds 2 missing columns to `service_items` table
- **Time:** ~30 seconds

### API Configuration: ⚠️ **One Fix Needed**
- **Issue:** API Base URL missing `/v1/`
- **Fix:** Change to `https://api.gtvmotor.dev/v1`
- **Other Settings:** ✅ All correct!

### Overall Status:
- ✅ **90% Correct** - Just need to:
  1. Add `/v1/` to Base URL
  2. Run database update script
  3. Generate and configure API key

---

## 🎯 Quick Fix Guide

### Fix 1: Update API Base URL (30 seconds)
1. Open Settings → API Configuration
2. Change Base URL from: `https://api.gtvmotor.dev`
3. Change Base URL to: `https://api.gtvmotor.dev/v1`
4. Click "Save API Settings"

### Fix 2: Update Database (1 minute)
```bash
mysql -u your_username -p your_database < backend/api/v1/update_database_minimal.sql
```

### Fix 3: Setup API Key (2 minutes)
1. Generate key: `php backend/api/v1/generate-api-key.php`
2. Copy generated key
3. Add to `backend/api/v1/config.php`
4. Paste in frontend settings form
5. Save

**Total Time:** ~3-4 minutes

---

## ✅ After Fixes

Once you've made these changes:
- ✅ Database will be 100% ready for API
- ✅ API Base URL will point to correct endpoint
- ✅ API Key will be configured
- ✅ All settings will be correct
- ✅ API will work perfectly!

---

## 📞 Need More Help?

- **API Key Guide:** `backend/api/v1/API_KEY_GUIDE.md`
- **Process Flow:** `backend/api/v1/API_PROCESS_FLOW.md`
- **Database Report:** `backend/api/v1/DATABASE_CHECK_REPORT.md`
- **Full Review:** `backend/api/v1/API_CONFIGURATION_REVIEW.md`

