# GTV Motor API v1 Documentation

## Base URL
```
https://api.gtvmotor.dev/v1/
```

## Authentication

All API requests require an API key. Include your API key in the request headers:

```
X-API-Key: your_api_key_here
```

Or using Authorization header:
```
Authorization: ApiKey your_api_key_here
```

## Endpoints

### 1. Customers API

#### Get All Customers
```
GET /v1/customers
```

**Query Parameters:**
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 20, max: 100)
- `search` - Search term (searches name, phone, email)
- `sortBy` - Sort field (default: created_at)
- `sortOrder` - Sort order: asc or desc (default: desc)

**Response:**
```json
{
  "success": true,
  "message": "Customers retrieved successfully",
  "data": [...],
  "pagination": {
    "total": 100,
    "page": 1,
    "limit": 20,
    "totalPages": 5
  }
}
```

#### Get Customer by ID
```
GET /v1/customers/{id}
```

**Response includes:**
- Customer basic information
- All vehicles associated with customer
- All services associated with customer
- Service items for each service
- Statistics (total spent, service counts, etc.)

### 2. Vehicles API

#### Get All Vehicles
```
GET /v1/vehicles
```

**Query Parameters:**
- `page` - Page number
- `limit` - Items per page
- `search` - Search term
- `customer_id` - Filter by customer ID
- `sortBy` - Sort field
- `sortOrder` - Sort order

#### Get Vehicle by ID
```
GET /v1/vehicles/{id}
```

**Response includes:**
- Vehicle complete information
- Customer information
- Vehicle model details
- All services for this vehicle
- Service items for each service
- Warranty information

#### Get Vehicle by Plate Number
```
GET /v1/vehicles?plate_number=ABC-1234
```

### 3. Service Invoices API

#### Get All Invoices
```
GET /v1/invoices
```

**Query Parameters:**
- `page` - Page number
- `limit` - Items per page
- `search` - Search term
- `customer_id` - Filter by customer ID
- `vehicle_id` - Filter by vehicle ID
- `start_date` - Filter from date (YYYY-MM-DD)
- `end_date` - Filter to date (YYYY-MM-DD)
- `sortBy` - Sort field
- `sortOrder` - Sort order

#### Get Invoice by ID
```
GET /v1/invoices/{id}
```

**Response includes:**
- Complete service information
- Customer details
- Vehicle details
- Service type information
- Staff information (technician, sales rep)
- Service items with pricing
- Invoice totals (subtotal, VAT, total)
- Exchange rate and KHR amount
- Payment information
- Status information

#### Get Invoice by Invoice Number
```
GET /v1/invoices?invoice_number=INV-251001-1234
```

## Response Format

All responses follow this format:

**Success Response:**
```json
{
  "success": true,
  "message": "Success message",
  "data": {...},
  "timestamp": "2024-10-01T12:00:00+00:00"
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Error message",
  "timestamp": "2024-10-01T12:00:00+00:00"
}
```

**Paginated Response:**
```json
{
  "success": true,
  "message": "Success message",
  "data": [...],
  "pagination": {
    "total": 100,
    "page": 1,
    "limit": 20,
    "totalPages": 5
  },
  "timestamp": "2024-10-01T12:00:00+00:00"
}
```

## Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized (Invalid or missing API key)
- `403` - Forbidden (API key doesn't have permission)
- `404` - Not Found
- `429` - Too Many Requests (Rate limit exceeded)
- `500` - Internal Server Error

## Rate Limiting

API requests are rate-limited per API key. Default rate limit is 1000 requests per hour. If exceeded, you'll receive a 429 status code.

## Configuration

API configuration is stored in `backend/api/v1/config.php`. This includes:
- API keys and permissions
- Rate limits
- Endpoint enable/disable settings
- Security settings

## Security Notes

1. **API Keys**: Store API keys securely. Never commit API keys to version control.
2. **HTTPS**: Always use HTTPS in production.
3. **Rate Limiting**: Respect rate limits to avoid being blocked.
4. **Permissions**: Each API key can have different permissions (read, write, etc.)

## Example Usage

### cURL Example
```bash
curl -X GET "https://api.gtvmotor.dev/v1/customers/1" \
  -H "X-API-Key: your_api_key_here"
```

### PHP Example
```php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.gtvmotor.dev/v1/customers/1");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "X-API-Key: your_api_key_here"
]);
$response = curl_exec($ch);
curl_close($ch);
```

### JavaScript Example
```javascript
fetch('https://api.gtvmotor.dev/v1/customers/1', {
  headers: {
    'X-API-Key': 'your_api_key_here'
  }
})
.then(response => response.json())
.then(data => console.log(data));
```

## Support

For API support, contact: api@gtvmotor.dev

