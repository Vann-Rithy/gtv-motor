<?php
/**
 * API Key Authentication Middleware
 * GTV Motor PHP Backend - API v1
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../../includes/Response.php';
require_once __DIR__ . '/ApiAnalytics.php';

class ApiAuth {

    /**
     * Validate API Key
     */
    public static function validateApiKey() {
        // Start analytics tracking
        ApiAnalytics::startTracking();

        // Get API key from header
        $apiKey = self::getApiKey();

        if (empty($apiKey)) {
            Response::unauthorized('API key is required. Please provide X-API-Key header.');
        }

        // Check if API key exists and is active
        $apiKeys = API_V1_KEYS;

        if (!isset($apiKeys[$apiKey])) {
            Response::unauthorized('Invalid API key.');
        }

        $keyConfig = $apiKeys[$apiKey];

        if (!$keyConfig['active']) {
            Response::forbidden('API key is inactive.');
        }

        // Check rate limiting
        if (API_V1_RATE_LIMIT_ENABLED) {
            self::checkRateLimit($apiKey, $keyConfig['rate_limit']);
        }

        // Log API request
        if (API_V1_LOG_REQUESTS) {
            self::logRequest($apiKey);
        }

        return $keyConfig;
    }

    /**
     * Get API Key from request headers
     */
    public static function getApiKey() {
        $headers = getallheaders();

        // Check X-API-Key header
        if (isset($headers['X-API-Key'])) {
            return trim($headers['X-API-Key']);
        }

        // Check Authorization header (Bearer token format)
        if (isset($headers['Authorization'])) {
            $auth = $headers['Authorization'];
            if (strpos($auth, 'Bearer ') === 0) {
                return trim(substr($auth, 7));
            }
            if (strpos($auth, 'ApiKey ') === 0) {
                return trim(substr($auth, 7));
            }
        }

        // Check query parameter (less secure, but sometimes needed)
        if (isset($_GET['api_key'])) {
            return trim($_GET['api_key']);
        }

        return null;
    }

    /**
     * Check rate limiting
     */
    private static function checkRateLimit($apiKey, $limit) {
        $rateLimitFile = __DIR__ . '/../../logs/rate_limit_' . md5($apiKey) . '.json';
        $currentHour = date('Y-m-d-H');

        $rateLimitData = [];
        if (file_exists($rateLimitFile)) {
            $rateLimitData = json_decode(file_get_contents($rateLimitFile), true) ?: [];
        }

        // Reset if new hour
        if (!isset($rateLimitData['hour']) || $rateLimitData['hour'] !== $currentHour) {
            $rateLimitData = [
                'hour' => $currentHour,
                'count' => 0
            ];
        }

        // Check limit
        if ($rateLimitData['count'] >= $limit) {
            Response::error('Rate limit exceeded. Maximum ' . $limit . ' requests per hour.', 429);
        }

        // Increment count
        $rateLimitData['count']++;

        // Save rate limit data
        if (!is_dir(dirname($rateLimitFile))) {
            mkdir(dirname($rateLimitFile), 0755, true);
        }
        file_put_contents($rateLimitFile, json_encode($rateLimitData));
    }

    /**
     * Log API request
     */
    private static function logRequest($apiKey) {
        $logFile = API_V1_LOG_FILE;
        $logDir = dirname($logFile);

        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }

        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'api_key' => substr($apiKey, 0, 10) . '...', // Partial key for logging
            'method' => $_SERVER['REQUEST_METHOD'],
            'uri' => $_SERVER['REQUEST_URI'],
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ];

        file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND);
    }

    /**
     * Check if request has required permission
     */
    public static function hasPermission($keyConfig, $permission) {
        if (!isset($keyConfig['permissions'])) {
            return false;
        }

        return in_array($permission, $keyConfig['permissions']) || in_array('*', $keyConfig['permissions']);
    }
}

?>
